import subprocess
import sys
import re

# Functions for the command
def build_description(description):
    new_description = description
    settings_file_path = "./project_djangobase/settings.py"
    with open(settings_file_path, "r") as f:
        settings_content = f.read()
    new_settings_content = re.sub(r"(BUILD_DESCRIPTION = ).*", rf"\1'{new_description}'", settings_content)
    with open(settings_file_path, "w") as f:
        f.write(new_settings_content)

def build_version(version):
    new_version = version
    settings_file_path = "./project_djangobase/settings.py"
    with open(settings_file_path, "r") as f:
        settings_content = f.read()
    new_settings_content = re.sub(r"(BUILD_VERSION = ).*", rf"\1'{new_version}'", settings_content)
    with open(settings_file_path, "w") as f:
        f.write(new_settings_content)

def run_git_command(command):
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, text=True)
        if result.returncode == 0:
            return result.stdout
        else:
            return result.stderr
    except Exception as e:
        return str(e)

######################################################################
def commit_all(message):
    result = run_git_command(f"git add -A && git commit -m \"{message}\"")
    print(result)
def show_status():
    result = run_git_command("git status")
    print(result)

def list_branches():
    remote_branches = run_git_command("git branch -r --sort=committerdate")
    local_branches = run_git_command("git branch --sort=committerdate")
    print("Remote branches:")
    print(remote_branches)
    print("Local branches:")
    print(local_branches)

def list_branches_nw():
    branches = run_git_command("git for-each-ref --sort=committerdate --format='%(committerdate:iso8601) %(refname:short)' refs/heads/")
    print("Branches (chronological order):")
    for line in branches.splitlines():
        print(line)

def list_tags():
    tags = run_git_command("git tag -n --sort=-taggerdate")
    print("Tags:")
    print(tags)


def list_tags_tlx():
    tags = run_git_command("git log --tags --simplify-by-decoration --pretty='%d'")
    print("Tags (chronological order):")
    print(tags)

def create_branch(branch_name):
    result = run_git_command(f"git checkout -b {branch_name}")
    print(result)

def create_tag(tag_name, target_desc):
    result = run_git_command(f"git tag {tag_name} -m \"{target_desc}\"")
    print(result)


def delete_branch(branch_name):
    result = run_git_command(f"git branch -D {branch_name}")
    print(result)

def delete_tag(tag_name):
    result = run_git_command(f"git tag -d {tag_name}")
    print(result)


def create_rel_tag(tag_name, description):
    result = run_git_command(f"git tag {tag_name} -m \"{description}\"")
    print(result)

def get_commit_history(target):
    commit_history = run_git_command(f"git log --pretty=oneline {target}")
    print("Commit History:")
    print(commit_history)

def switch_to_branch(branch_name):
    result = run_git_command(f"git checkout {branch_name}")
    print(result)

def get_current_branch():
    branch_name = run_git_command("git rev-parse --abbrev-ref HEAD")
    print("Current branch:", branch_name.strip())

# release 
def release_version(tag_name, version):
    cmd_is = f"git tag -a {tag_name} -m \"Release {version}\""
    result = run_git_command(cmd_is)
    #print(cmd_is)
    print(result)

def mark_existing_tag_as_release(tag_name, version):
    result = run_git_command(f"git tag -af {tag_name} -m \"Release {version}\"")
    print(result)

def push_mirror():
    result = run_git_command(f"git push origin --mirror")
    print(result)
####################################################################################

if __name__ == "__main__":
    available_commands = "Available commands: branches, tags, create branch or tag, history, commit, switch, release, release-existing"
    if len(sys.argv) < 2:
        print(f"Usage: vcs command [arguments] ==> {available_commands}")
        sys.exit(1)

    command = sys.argv[1]

    if command == "branches":
        list_branches()
    elif command == "tags":
        list_tags()
    elif command == "create":
        if len(sys.argv) < 4:
            print("Usage: vcs create branch_name|tag_name")
            sys.exit(1)
        target_type = sys.argv[2]
        target_name = sys.argv[3]
        target_desc = sys.argv[3]
        if target_type == "branch":
            create_branch(target_name)
        elif target_type == "tag":
            create_tag(target_name, target_desc)
        else:
            print("Invalid target type. Available types: branch, tag")
    elif command == "delete":
        if len(sys.argv) < 4:
            print("Usage: vcs delete branch_name|tag_name")
            sys.exit(1)
        target_type = sys.argv[2]
        target_name = sys.argv[3]
        if target_type == "branch":
            delete_branch(target_name)
        elif target_type == "tag":
            delete_tag(target_name)
        else:
            print("Invalid target type. Available types: branch, tag")
    elif command == "history":
        if len(sys.argv) > 2:
            target = sys.argv[2]
        else:
            target = "main"  # Default to "main" branch if no argument provided
        get_commit_history(target)
    elif command == "switch":
        if len(sys.argv) < 3:
            print("Usage: vcs switch branch_name")
            sys.exit(1)
        branch_name = sys.argv[2]
        switch_to_branch(branch_name)
    elif command == "current":
        get_current_branch()

    elif command == "release":
        if len(sys.argv) < 4:
            print("Usage: vcs release tag_name version")
            sys.exit(1)
        tag_name = sys.argv[2]
        version = sys.argv[3]
        release_version(tag_name, version)
    elif command == "release-existing":
        if len(sys.argv) < 4:
            print("Usage: vcs release-existing tag_name version")
            sys.exit(1)
        tag_name = sys.argv[2]
        version = sys.argv[3]
        mark_existing_tag_as_release(tag_name, version)
    elif command == "commit":
        if len(sys.argv) < 3:
            print("Usage: vcs commit message")
            sys.exit(1)
        message = sys.argv[2]
        commit_all(message)
    elif command == "status":
        show_status()
    elif command == "push-mirror":
        push_mirror()
    elif command == "build-desc":
        if len(sys.argv) < 2:
            print("Usage: vcs build-desc 'description of the build'")
            sys.exit(1)
        target_type = sys.argv[1]
        description = sys.argv[2]
        if target_type == "build-desc":
            build_description(description)
    elif command == "make-rel":
        if len(sys.argv) < 3:
            print("Usage: vcs make-rel 1.3.1 'description of the build'")
            sys.exit(1)
        target_type = sys.argv[1]
        version = sys.argv[2]
        description = sys.argv[3]
        if target_type == "make-rel":
            tag_version = f"v{version}"
            tag_comments = f"{description}"
            print(f"Relase Build: '{version} - {description}'")
            build_version(tag_version)
            build_description(tag_comments)
            commit_all(f"Release build: v{version} {description}")            
            create_rel_tag(tag_version, tag_comments)
    else:
        print(f"Invalid command. {available_commands}")


# what are the commands
# make-rel
# create branch / tag
# delete branch / tag
# commit
# tags
# branches
# switch
# push-mirror