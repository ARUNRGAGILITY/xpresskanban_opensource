# context_processors.py

from django.conf import settings

def build_version(request):
    return {'BUILD_VERSION': settings.BUILD_VERSION}

def build_description(request):
    return {'BUILD_DESCRIPTION': settings.BUILD_DESCRIPTION}