from django import forms
from .models import Project, Product, Service, Solution, ValueStream

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = '__all__'

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = '__all__'

class SolutionForm(forms.ModelForm):
    class Meta:
        model = Solution
        fields = '__all__'

class ValueStreamForm(forms.ModelForm):
    class Meta:
        model = ValueStream
        fields = '__all__'


## for the user mgmt
class DeleteUserConfirmationForm(forms.Form):
    confirm = forms.BooleanField(required=True)

## for the group mgmt
class DeleteGroupConfirmationForm(forms.Form):
    confirm = forms.BooleanField(required=True)

