from django.urls import path
from .views import *

urlpatterns = [
    # multiple-model-CRUD
    #path('edit/<str:model_name>/<int:pk>/', views.edit_object, name='edit_object'),
    # main home for the MVP
    path('', main_home, name='main_home'),
    # User Mgmt
    path('usermgmt/home/', user_home, name='user_mgmt_home'),
    path('usermgmt/list/', user_list, name='user_mgmt_list'),
    path('usermgmt/restore-deleted-user-list/', restore_user_list, name='user_mgmt_restore'),
    path('usermgmt/create/', user_create, name='user_mgmt_create'),
    path('usermgmt/create-multiple/', user_create_multiple, name='user_mgmt_create_multiple'),
    path('usermgmt/<int:pk>/', user_detail, name='user_mgmt_detail'),
    path('usermgmt/<int:pk>/update/', user_update, name='user_mgmt_update'),
    path('usermgmt/<int:pk>/delete/', user_delete, name='user_mgmt_delete'),
    path('ops_user_mgmt', ops_user_mgmt, name='ops_user_mgmt'),
    path('bulk_ops_user_mgmt', bulk_ops_user_mgmt, name='bulk_ops_user_mgmt'),
    # Group
    path('groupmgmt/home/', group_home, name='group_mgmt_home'),
    path('groupmgmt/list/', group_list, name='group_mgmt_list'),
    path('groupmgmt/create/', group_create, name='group_mgmt_create'),
    path('groupmgmt/<int:pk>/update/', group_update, name='group_mgmt_update'),
    path('groupmgmt/<int:pk>/delete/', group_delete, name='group_mgmt_delete'),
    path('groupmgmt/<int:pk>/', group_detail, name='group_mgmt_detail'),
    path('ops_group_mgmt', ops_group_mgmt, name='ops_group_mgmt'),
    path('group_mgmt/restore_deleted_groups/', restore_deleted_groups, name='restore_deleted_groups'),
    path('bulk_ops_group_mgmt', bulk_ops_group_mgmt, name='bulk_ops_group_mgmt'),
    path('groupmgmt/<int:pk>/list_users/', group_mgmt_list_users, name='group_mgmt_list_users'),
]
