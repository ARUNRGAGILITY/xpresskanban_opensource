from django.apps import AppConfig


class AppXpresskanbanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_xpresskanban'
