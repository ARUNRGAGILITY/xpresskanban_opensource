April 10th 2023

https://github.com/ARUNRGAGILITY/djangobase

/c/daa/VVVV_IMPORTANT/djangobase_dir/djangobase

this will be the base directory for all apps for deployment

build features in branches, check and merge to main, while main can be used to deploy the LCD


