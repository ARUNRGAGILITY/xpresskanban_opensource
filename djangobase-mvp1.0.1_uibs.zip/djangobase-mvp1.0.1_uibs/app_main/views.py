from django.shortcuts import render

# Create your views here.
from django.db import models
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from app_main.models import *

# Assuming you have your models (Project, Product, Service, Solution) defined as before
# ... Other view functions ...

    

# ... Other view functions ...

@login_required(login_url='login')
def add_object(request, model_name):
    model_class = None
    if model_name == 'project':
        model_class = Project
    elif model_name == 'product':
        model_class = Product
    elif model_name == 'service':
        model_class = Service
    elif model_name == 'solution':
        model_class = Solution
    elif model_name == 'value_stream':
        model_class = ValueStream
    if model_class is not None:
        if request.method == 'POST':
            # Here, we use the relevant form for the model
            form = globals()[model_name.capitalize() + 'Form'](request.POST)
            if form.is_valid():
                form.instance.author = request.user
                obj = form.save()

                # Handle any specific logic for creating related objects
                if model_name == 'product':
                    if not NewTodoList.objects.filter(product=obj).exists():
                        # Create a related Backlog entry only if it doesn't exist
                        backlog_title = f"{obj.title} Backlog"
                        backlog = NewTodoList.objects.create(
                            title=backlog_title,
                            product=obj,
                            active=True,
                            author=request.user,
                            workitemtype=form.cleaned_data['work_item_type']
                        )

                # Handle form submission success
                return redirect('navbar_' + model_name)
        else:
            # Here, we use the relevant form for the model
            form = globals()[model_name.capitalize() + 'Form']()
        context = {'page': 'Add ' + model_name.capitalize(), 'form': form}
        return render(request, 'general_templates/navbar/define/' + model_name + '/add_' + model_name + '.html', context)
    else:
        # Handle invalid model name
        return redirect('home')  # Redirect to a proper error page or other handling
    

@login_required(login_url='login')
def view_object(request, model_name, pk):
    model_class = None
    if model_name == 'project':
        model_class = Project
    elif model_name == 'product':
        model_class = Product
    elif model_name == 'service':
        model_class = Service
    elif model_name == 'solution':
        model_class = Solution
    elif model_name == 'value_stream':
        model_class = ValueStream

    if model_class is not None:
        obj = get_object_or_404(model_class, pk=pk)
        context = {model_name: obj}
        return render(request, 'general_templates/navbar/define/' + model_name + '/view_' + model_name + '.html', context)
    else:
        # Handle invalid model name
        return redirect('home')  # Redirect to a proper error page or other handling

@login_required(login_url='login')
def edit_object(request, model_name, pk):
    model_class = None
    if model_name == 'project':
        model_class = Project
    elif model_name == 'product':
        model_class = Product
    elif model_name == 'service':
        model_class = Service
    elif model_name == 'solution':
        model_class = Solution
    elif model_name == 'value_stream':
        model_class = ValueStream

    if model_class is not None:
        obj = get_object_or_404(model_class, pk=pk)
        form = model_classForm(instance=obj)
        if request.method == 'POST':
            form = model_classForm(request.POST, instance=obj)
            if form.is_valid():
                form.instance.author = request.user
                form.save()
                return redirect('navbar_' + model_name)
        else:
            form = model_classForm(instance=obj)
        context = {'form': form, model_name: obj}
        return render(request, 'general_templates/navbar/define/' + model_name + '/edit_' + model_name + '.html', context)
    else:
        # Handle invalid model name
        return redirect('home')  # Redirect to a proper error page or other handling

@login_required(login_url='login')
def delete_object(request, model_name, pk):
    model_class = None
    if model_name == 'project':
        model_class = Project
    elif model_name == 'product':
        model_class = Product
    elif model_name == 'service':
        model_class = Service
    elif model_name == 'solution':
        model_class = Solution
    elif model_name == 'value_stream':
        model_class = ValueStream

    if model_class is not None:
        obj = get_object_or_404(model_class, pk=pk)
        context = {model_name: obj}
        if request.method == 'POST':
            model_class.objects.filter(id=pk).update(active=False, author=request.user)
            return redirect('navbar_' + model_name)
        return render(request, 'general_templates/navbar/define/' + model_name + '/delete_' + model_name + '.html', context)
    else:
        # Handle invalid model name
        return redirect('home')  # Redirect to a proper error page or other handling

# Add other views like "copy_object", "restore_object", etc. following the same pattern

