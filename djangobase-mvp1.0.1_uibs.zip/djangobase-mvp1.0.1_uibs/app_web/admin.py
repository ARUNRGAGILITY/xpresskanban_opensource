from django.contrib import admin
from .models import *

admin.site.register(Project)
admin.site.register(ProjectType)
admin.site.register(ProjectState)
admin.site.register(ProjectPriority)

admin.site.register(Product)
admin.site.register(ProductType)
admin.site.register(ProductState)
admin.site.register(ProductPriority)

admin.site.register(VSM)
admin.site.register(VSMS_Info)
admin.site.register(VSMS_Steps)

admin.site.register(Planner)

class UserPreferenceAdmin(admin.ModelAdmin):
    # List all fields in the admin interface
    list_display = [field.name for field in UserPreference._meta.get_fields()]
admin.site.register(UserPreference, UserPreferenceAdmin)




    