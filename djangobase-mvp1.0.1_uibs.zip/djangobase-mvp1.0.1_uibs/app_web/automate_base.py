#     
# Need, Idea, Problem, Solution => Define
# Gain/Pain => Evaluate
# Value Prop => Build
# 
# 
# Value Prop Statement
#  For - (Target Customer Segments)
#  dissatisfied with (existing solutions)
#  due to (key unmet needs),
#  (Venture name) offers a (product category)
#  that provides (key benefits of your solution)
# 
# 

    # URL for __ONEURL__
    path('navbar___ONEURL__', navbar___ONEURL__, name="navbar___ONEURL__"),
    path('add___ONEURL__', add___ONEURL__, name="add___ONEURL__"),
    path('ops___ONEURL__', ops___ONEURL__, name="ops___ONEURL__"),
    path('view___ONEURL__/<int:pk>', view___ONEURL__, name="view___ONEURL__"),
    path('__ONEURL___homepage/<int:pk>', __ONEURL___homepage, name="__ONEURL___homepage"),
    path('edit___ONEURL__/<int:pk>', edit___ONEURL__, name="edit___ONEURL__"),
    path('delete___ONEURL__/<int:pk>', delete___ONEURL__, name="delete___ONEURL__"),
    path('restore___ONEURL__/<int:pk>', restore___ONEURL__, name="restore___ONEURL__"),
    path('restore___ONEURL__/<int:pk>', restore___ONEURL__, name="restore___ONEURL__"),
    path('restore___ONEURL__s', restore___ONEURL__s, name="restore___ONEURL__s"),
    path('bulk_restore_deleted___ONEURL__s', bulk_restore_deleted___ONEURL__s, name="bulk_restore_deleted___ONEURL__s"),
    path('sorted___ONEURL__',sorted___ONEURL__, name='sorted___ONEURL__'),



class __ONEMODEL__State(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='__ONEMODEL__state')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')

class __ONEMODEL__Priority(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='__ONEMODEL__priority')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')

class __ONEMODEL__Type(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='__ONEMODEL__type')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')


class __ONEMODEL__(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    work_item_type = models.ForeignKey(TypeList, on_delete=models.SET_NULL, null=True, blank=True)
    project_type = models.ForeignKey(__ONEMODEL__Type, null=True, blank=True, related_name='__ONEMODEL___type', on_delete=models.CASCADE)
    project_priority = models.ForeignKey(__ONEMODEL__Priority, null=True, blank=True, related_name='__ONEMODEL___priority', on_delete=models.CASCADE)
    project_state = models.ForeignKey(__ONEMODEL__State, null=True, blank=True, related_name='__ONEMODEL___state', on_delete=models.CASCADE)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    progress = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    current_state = models.TextField(null=True, blank=True, default='')
    done = models.BooleanField(default=False)

    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_in_hours = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='__ONEMODEL__1')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')


#### views


@login_required(login_url='login')
def navbar_project(request):
    context = {'page': 'Project'}
    pagination_on = False
    # here we list all projects
    newtodolist = Project.objects.filter(active=True).order_by('position')
    newtodolist_count = newtodolist.count()
    form = ProjectForm(request.user)
    # pagination
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)
    
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 'pagination':selected_pagination, 'paginated_items': paginated_items, 'pagination_on': pagination_on}
    return render(request, 'general_templates/navbar/define/project/list_projects.html', context)

@login_required(login_url='login')
def add_project(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():

            form.instance.author = request.user
            project = form.save()
            #######################################
            if not NewTodoList.objects.filter(project=project).exists():
                # Create a related Backlog entry only if it doesn't exist
                backlog_title = f"{project.title} Backlog"
                backlog = NewTodoList.objects.create(title=backlog_title, 
                            project=project, active=True, author=request.user,
                            workitemtype=form.cleaned_data['work_item_type'])            
            # Handle form submission success
            return redirect('navbar_project')
    else:
        form = ProjectForm()
    
    context = {'page': 'Add Project', 'form': form}
    return render(request, 'general_templates/navbar/define/project/add_project.html', context)


@login_required(login_url='login')
def view_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {'project': project}
    return render(request, 'general_templates/navbar/define/project/view_project.html', context)

@login_required(login_url='login')
def project_homepage(request, pk):
    form = ProjectForm()
    project = get_object_or_404(Project, pk=pk)
    backlogs = project.backlogs.all()
    backlog = get_object_or_404(NewTodoList, project=project)
    newtodolistitems = project
    newtodolistitems_count = project.backlogs.filter(active=True).count()
    if request.method == 'POST':
        print(f"Received PROJECT HOME PAGE >>>> FORM")
    context = {'newtodolistitems': newtodolistitems, 'form': form, 'backlog_id': backlog.id,
               'backlog': backlog,
               'todolist_parent_id ': pk, 'newtodolistitems_count': newtodolistitems_count, 'project': project, 'backlogs':backlogs}
    return render(request, 'general_templates/navbar/define/project/project_homepage.html', context)

@login_required(login_url='login')
def edit_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    form = ProjectForm(instance=project)
    if request.method == 'POST':
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            return redirect('navbar_project')
    else:
        form = ProjectForm(instance=project)
    context = {'form': form, 'project': project}
    return render(request, 'general_templates/navbar/define/project/edit_project.html', context)


@login_required(login_url='login')
def delete_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {'project': project}
    if request.method == 'POST':
        Project.objects.filter(id=pk).update(active=False, deleted=False,  author=request.user)
        return redirect('navbar_project')
    return render(request, 'general_templates/navbar/define/project/delete_project.html', context)


@login_required(login_url='login')
def copy_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    new_project = Project()
    new_project.title = project.title + " (Copy)"
    new_project.description = project.description
    new_project.project_type = project.project_type
    new_project.project_priority = project.project_priority
    new_project.project_state = project.project_state
    new_project.start_date = project.start_date
    new_project.end_date = project.end_date
    new_project.current_state = project.current_state

    new_project.save()
    new_project_id = new_project.id
    #######################################
    if not NewTodoList.objects.filter(project=project).exists():
        # Create a related Backlog entry only if it doesn't exist
        backlog_title = f"{new_project.title} Backlog"
        backlog = NewTodoList.objects.create(title=backlog_title, 
                    project=new_project, active=True, author=request.user,
                    workitemtype=project.work_item_type)
    context = {'project': project, 'new_project_id':new_project_id, 
               'new_project':new_project, 'backlog': backlog}
    return render(request, 'general_templates/navbar/define/project/copy_project.html', context)


@login_required(login_url='login')
def ops_project(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_project_ids = request.POST.getlist('project_box')        
        bulk_ops = form_data.get('bulk_project_ops')
        pagination = form_data.get('pagination')
        bulk_ops = form_data.get('bulk_project_ops')
        if bulk_ops == "bulk_delete":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(active=False, deleted=False,  author=request.user)
        elif bulk_ops == "bulk_done":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(done=True,  author=request.user)
        print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 'selected_project_ids':selected_project_ids}
    return render(request, 'general_templates/navbar/define/project/bulk_project_ops.html', context)

@login_required(login_url='login')
def project_sorted(request):
    if request.method == 'POST':
        ajax_data = request.POST['sorted_list_data']
        new_data = ajax_data.replace("[",'')
        new_data = new_data.replace("]",'')
        sorted_list = new_data.split(",")
        seq = 1
        for item in sorted_list:
            str = item.replace('"','')
            position = str.split('_')
            Project.objects.filter(pk=position[0]).update(position=seq)
            seq = seq + 1
        return render(request, 'general_templates/navbar/define/navbar_project.html', {'ajax_data': ajax_data})


@login_required(login_url='login')
def restore_projects(request):
    context = {'page': 'Restore Projects'}
    # here we list all projects deleted and restore
    newtodolist = Project.objects.filter(active=False, deleted=False).order_by('position')
    newtodolist_count = newtodolist.count()
    form = ProjectForm(request.user)
    if request.method == 'POST':
        form = ProjectForm(request.user, request.POST)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            todo_count = newtodolist.count()
            return redirect('navbar_project')
        else:
            print(f"form is invalid {form}")
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return render(request, 'general_templates/navbar/define/project/restore_projects.html', context)

@login_required(login_url='login')
def restore_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {'project': project}
    if request.method == 'POST':
        Project.objects.filter(id=pk).update(active=True,  author=request.user)
        return redirect('restore_projects')
    return render(request, 'general_templates/navbar/define/project/restore_project.html', context)



@login_required(login_url='login')
def bulk_restore_deleted_projects(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_project_ids = request.POST.getlist('restore_project_box')        
        bulk_ops = form_data.get('bulk_project_ops')
        if bulk_ops == "bulk_restore":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(active=True,  author=request.user)
        elif bulk_ops == "bulk_not_done":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(done=False,  author=request.user)
        elif bulk_ops == "bulk_delete_permanently":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(active=False, deleted=True,  author=request.user)
        pagination = form_data.get('pagination')
        print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 'selected_project_ids':selected_project_ids}
    return render(request, 'general_templates/navbar/define/project/bulk_restore_ops.html', context)


# templates
add___ONETEMP__.html
{% extends "base.html" %} 
{% load static %}
{% block title %}Add Project{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}


<form action="" method='POST' class='form'>
    {% if form.errors %}
      <div class="alert alert-danger">
        {{form.errors}}
      </div>
    {% endif %}
    {% csrf_token %}
      
    <div class="container-fluid mx-2 ">
        <div class="row mb-0">
            <div class="col-md-6 d-flex justify-content-start align-items-center">
                <span class="icon-text">
                    <span class="icon" >
                        <img width="60px" height="60px" 
                        src="{% static 'img/plan1.svg' %}" 
                        class="" alt="" style="max-height: 40px;">  
                    </span>                   
                    &nbsp;
                    <b>Project</b>
                </span>
            </div>
            <div class="col-md-6 d-flex justify-content-end align-items-center">                
                <a href="{% url 'navbar_project' %}">List Projects</a>
                &nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="{% url 'restore_projects' %}">Restore</a>
                &nbsp;&nbsp;
            </div>
        </div>
        <div class="row py-1">
            <div class="column is-12 has-background-grey-light">
                <b>Add Project Details</b>              
            </div>
            
        </div>
        <div class="row py-1">
            <div class="col-md-1 d-flex justify-content-start align-items-center">
                {{ form.title.label_tag }} 
            </div>
            <div class="col-md-11 d-flex justify-content-start align-items-cente">
                <input type="text" name="title" size="40" value="">
            </div>
        </div>      
        <div class="row py-1">
            <div class="col-md-1 d-flex justify-content-start align-items-center">
                {{ form.description.label_tag }}
            </div>
            <div class="col-md-11 d-flex justify-content-start align-items-center">
                <textarea name="description" id="description" cols="43" rows="6"></textarea>
            </div>
        </div>
        <div class="row py-1">
            <div class="col-md-1 d-flex justify-content-start align-items-center">
                Project
            </div>
            <div class="col-md-11 d-flex justify-content-start align-items-center">
                Type:  &nbsp;&nbsp;{{ form.project_type }}
                &nbsp;&nbsp;Priority:  &nbsp;&nbsp;{{ form.project_priority }}
                &nbsp;&nbsp;State:  &nbsp;&nbsp;{{ form.project_state }}
            </div>
        </div>
        
        <div class="row py-1">
            <div class="col-md-1 d-flex justify-content-start align-items-center">
                Duration: 
            </div>
            <div class="col-md-11 d-flex justify-content-start align-items-center">
                Start Date: &nbsp;&nbsp;{{ form.start_date }} &nbsp;&nbsp; End Date:  &nbsp;&nbsp; {{ form.end_date }}
            </div>
        </div> 
        <div class="row py-1">
            <div class="col-md-1 d-flex justify-content-start align-items-center">
                Backlog Template: 
            </div>
            <div class="col-md-11 d-flex justify-content-start align-items-center">
                {{form.work_item_type}}
            </div>
        </div>      
        <div class="row py-1">
            <div class="col-md-12 d-flex justify-content-start align-items-center">
                <input type='submit' value='Add Project'/>
            </div>
        </div>
    </div>
       
    
</form>
{% endblock content %}

bulk___ONETEMP___ops.html

{% extends "base.html" %} 
{% load static %}
{% block title %}Dev Product{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <a href="{% url 'navbar_project' %}">List of Projects</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9">
            <h5>Bulk Operations on Project(s)</h5>
            {% for id in selected_project_ids %}
                <b>Project ID: {{id}}</b><br>
            {% endfor %}
            <p>has been {{bulk_ops}}.</p>
        </div>
    </div>
</div>
{% endblock content %}

copy___ONETEMP__.html
{% extends "base.html" %} 
{% load static %}
{% block title %}Add Project{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <h6>Copied/Cloned Project Details</h6>
        </div>
        <div class="col-md-9 d-flex justify-content-end">
            <a href="{% url 'view_project' project.id %}">View Src Project</a>&nbsp;&nbsp;
            <a href="{% url 'view_project' new_project.id %}">View Cloned Project</a>&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Project List</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9">
            <b>Project ID {{project.id}} is successfully cloned as {{new_project.id}} as {{new_project.title}}</b>
        </div>
    </div>
</div>  
{% include '../../../../5.footer.html' %}
{% endblock content %}


delete___ONETEMP__.html

{% extends "base.html" %} 
{% load static %}
{% block title %}Edit Project{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <h5>Delete Project</h5>
        </div>
        <div class="col-md-4"></div>
    </div>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <form action="" method='POST' class='form'>
                {% csrf_token %}
                <div class="form__group">
                <p>Do you want to delete this Project <b>{{project}}</b>?</p>
                </div>
                <div class="for__group">
                <input type="submit" value='Confirm Delete' class='btn btn-danger'>
                &nbsp;&nbsp;
                <input type="reset" value='Cancel' class='btn btn-warning'>
                </div>
                </form>
        </div>
        <div class="col-md-4"></div>
    </div>
</div>
{% endblock content %}

edit___ONETEMP__.html

{% extends "base.html" %} 
{% load static %}
{% block title %}Edit Project{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<form action="" method='POST' class='form'>
{% csrf_token %}
<div class="container-fluid">
    <div class="row">
        <div class="col-md-9 d-flex justify-content-start align-items-center">
            <h6>Edit Project Details</h6>
        </div>
        <div class="col-md-3 d-flex justify-content-end align-items-center">
            <a href="{% url 'view_project' project.id %}">View Project</a>&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Project List</a>
        </div>

    </div>
    <div class="row">
        <div class="col-md-9">
            Project ID: &nbsp;<b>{{project.id}}</b>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9">
            {{form.as_p}}
        </div>
    </div>
    <div class="row">
        <div class="col-md-9">
            <input type="submit" name="Edit Project">
        </div>
    </div>
</div>
{% include '../../../../5.footer.html' %}
{% endblock content %}

list___ONETEMP__.html

{% extends "base.html" %} 
{% load static %}
{% load crispy_forms_tags %}
{% block title %}Projects{% endblock title %} 
{% block content %}
{% if user.is_authenticated %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<style>
    #sortable { list-style-type: none; margin: 0; padding: 0; width: 60%; }
    #sortable li { margin: 0 3px 3px 3px; padding: 0.4em; padding-left: 1.5em; font-size: 1.4em; height: 18px; }
    #sortable li span { position: absolute; margin-left: -1.3em; }
    </style>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$( function() {
  // on load hide the datetime details and show when checkbox selected

  $('td:nth-child(6),th:nth-child(6)').hide();
  $('td:nth-child(7),th:nth-child(7)').hide();
  $('td:nth-child(8),th:nth-child(8)').hide();
  $('td:nth-child(9),th:nth-child(9)').hide();
  $('td:nth-child(10),th:nth-child(10)').hide();
  $('td:nth-child(11),th:nth-child(11)').hide();
  $('td:nth-child(12),th:nth-child(12)').hide();
  $('td:nth-child(13),th:nth-child(13)').hide();
  $(".show_hide_details").click(function (event) {
        var checkbox_data = $(this).attr('id');
        var checkbox_this = $(this);
        if ($(this).prop('checked')==true){ 
          //alert("show");
            $('td:nth-child(5),th:nth-child(5)').show();
            $('td:nth-child(6),th:nth-child(6)').show();
            $('td:nth-child(7),th:nth-child(7)').show();
            $('td:nth-child(8),th:nth-child(8)').show();
            $('td:nth-child(9),th:nth-child(9)').show();
            $('td:nth-child(10),th:nth-child(10)').show();
            $('td:nth-child(11),th:nth-child(11)').show();
            $('td:nth-child(12),th:nth-child(12)').show();
        } else {
            $('td:nth-child(5),th:nth-child(5)').hide();
            $('td:nth-child(6),th:nth-child(6)').hide();
            $('td:nth-child(7),th:nth-child(7)').hide();
            $('td:nth-child(8),th:nth-child(8)').hide();
            $('td:nth-child(9),th:nth-child(9)').hide();
            $('td:nth-child(10),th:nth-child(10)').hide();
            $('td:nth-child(11),th:nth-child(11)').hide();
            $('td:nth-child(12),th:nth-child(12)').hide();
        }
  });



  // sorted list
  
  $( "#sortable" ).sortable({
      stop: function(event, ui) {
        var serialOrder = $('#sortable').sortable('serialize');
        var arrayOrder = $('#sortable').sortable('toArray');
        $.ajax({
          url: '/web/sorted_project',
          type: 'POST',
          data : {
            'csrfmiddlewaretoken': "{{ csrf_token }}",
            'sorted_list_data': JSON.stringify(arrayOrder)
          },
          dataType: 'json',
          success: function(data) {
            console.log(data);
          }
        });
         $(this).find('tr').each(function(i){
            $(this).children('td:second').text(i+1);
        });
      }
  });
  $( "#sortable" ).sortable();
  $( "#sortable" ).disableSelection();
});
</script>

<form action="{% url 'ops_project' %}" name="" method="POST">
{% csrf_token %}
<div class="container-fluid ">
  <div class="row mx-0 my-1">
      <div class="col-md-12 mx-0 d-flex justify-content-start" style="background-color: lightblue;">
      <b>Project Page</b>    
      </div>
  </div>
  <div class="row mx-0 my-1">
      <div class="col-md-6 d-flex justify-content-start align-items-center">
          <b>Project List</b>
          &nbsp;&nbsp;           
          <input type="checkbox" name='show_hide' class='show_hide_details'>
          &nbsp;&nbsp;<font size='-2'>Show Details</font>
      </div>
      <div class="col-md-6 d-flex justify-content-end align-items-center">
          <b>Display:</b>&nbsp;&nbsp;
          <select name="pagination" id="paginationselect">
              <option value="none">-Select-</option>
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="15">15</option>
              <option value="25">25</option>
              <option value="50">50</option>
              <option value="100">100</option>
              <option value="all">All</option>
          </select>
          &nbsp;&nbsp;
          <b>Bulk:</b>&nbsp;&nbsp;
          <select name="bulk_project_ops" id="bulk_project_ops" onchange="this.form.submit()">
              <option value="none">-Select-</option>
              <option value="bulk_delete">Delete</option>
              <option value="bulk_done">Done</option>
          </select>
          &nbsp;&nbsp;
          <a href="{% url 'add_project' %}" class="btn btn-success">Add New Project</a>
          &nbsp;&nbsp;
          <a href="{% url 'restore_projects' %}">
              Restore
          </a>
          &nbsp;&nbsp;
      </div>
  </div>

    <div class="row">
        <div class="col-md-12">
            <table  id="outline" class="table is-bordered" bgcolor="lightgreen">
                <tr>
                    <th>
                        <input type="checkbox" name="select_all" id="select_all" onclick='checkUncheck(this)'>
                    </th>
                    <th>#</th>
                    <th>ID</th>
                    <th>Project Name</th>
                    <th>Description</th>

                    <th>Type</th>
                    <th>Priority</th>
                    <th>State</th>
                    <th>Start Date</th>

                    <th>End Date</th>
                    <th>Progress</th>
                    <th>Done</th>
                    <th>Note</th>  

                    <th>Action</th>
                </tr>
                <tbody id="sortable">
                {% for todo in paginated_items %}
                <tr id="{{todo.id}}_{{ forloop.counter }}" class="ui-state-default" style='background-color: white;'>
                    <td>
                        <input type="checkbox" name="project_box" id="selected_project_ids" value="{{todo.id}}">
                    </td>
                    <td>{{forloop.counter}}</td>
                    <td>{{todo.id}}</td>
                    <td>{{todo.title}}</td>
                    <td>{{todo.description}}</td>
                    <td>{{todo.project_type}}</td>
                    <td>{{todo.project_priority}}</td>
                    <td>{{todo.project_state}}</td>
                    <td>{{todo.start_date}}</td>
                    <td>{{todo.end_date}}</td>
                    <td>{{todo.progress}}</td>
                    <td>{{todo.done}}</td>
                    <td>{{todo.current_state}}</td>                    
                    <td>
                        <a href="{% url 'project_homepage' todo.id %}">Details</a>&nbsp;
                        <a href="{% url 'view_project' todo.id %}">View</a>&nbsp;
                        <a href="{% url 'edit_project' todo.id %}">Edit</a>&nbsp;
                        <a href="{% url 'delete_project' todo.id %}">Delete</a>&nbsp;
                        <a href="{% url 'copy_project' todo.id %}">Copy</a>&nbsp;
                        <!--
                        <select name="project_action" id="">
                            <option value="none">-Select-</option>
                            <option value="view_project">View</option>
                            <option value="edit_project">Edit</option>
                            <option value="delete_project">Delete</option>
                            <option value="copy_project">Copy</option>
                        </select>
                        -->
                    </td>
                </tr>
                {% endfor %}
                </tbody>                
            </table>
        </div>
    </div>
</div>
</form>
<!-- Display the pagination links -->
<div class="container">
    <div class="row">
        <div class="col-md-12 d-flex justify-content-center py-2">
            <div class="pagination">
                <span class="step-links">
                  {% if paginated_items.has_previous %}
                    <a href="?page=1&pagination={{pagination}}">&laquo; first</a>
                    <a href="?page={{ paginated_items.previous_page_number }}&pagination={{pagination}}">previous</a>
                  {% endif %}
                
                  {% if pagination_on %} 
                  <span class="current">
                    Page {{ paginated_items.number }} of {{ paginated_items.paginator.num_pages }}.
                  </span>
                  {% endif %}
              
                  {% if paginated_items.has_next %}
                    <a href="?page={{ paginated_items.next_page_number }}&pagination={{pagination}}">next</a>
                    <a href="?page={{ paginated_items.paginator.num_pages }}&pagination={{pagination}}">last &raquo;</a>
                  {% endif %}
                </span>
              </div>
        </div>
    </div>
</div>

<script>
function checkUncheck(checkBox) {
    get = document.getElementsByName('project_box');
    for(var i=0; i<get.length; i++) {
        get[i].checked = checkBox.checked;
    }
}
// pagination select
document.addEventListener("DOMContentLoaded", function () {
  const redirectSelect = document.getElementById("paginationselect");
  redirectSelect.addEventListener("change", function () {
    const selectedValue = redirectSelect.value;
    
    // Redirect the user based on the selected value
    if (selectedValue === "5") {
      window.location.href = "{% url 'navbar_project' %}?page=1&pagination=5";
    } else if (selectedValue === "10") {
      window.location.href = "{% url 'navbar_project' %}?page=1&pagination=10";
    } else if (selectedValue === "15") {
      window.location.href = "{% url 'navbar_project' %}?page=1&pagination=15";
    } else if (selectedValue === "25") {
      window.location.href = "{% url 'navbar_project' %}?page=1&pagination=25";
    } else if (selectedValue === "50") {
      window.location.href = "{% url 'navbar_project' %}?page=1&pagination=50";
    } else if (selectedValue === "100") {
      window.location.href = "{% url 'navbar_project' %}?page=1&pagination=100";
    } else if (selectedValue === "all") {
      window.location.href = "{% url 'navbar_project' %}?page=1&pagination=all";
    } 
    // Add more conditions for other options as needed
  });
});
</script>
{% else%}
  {% include 'GUEST_USER.html' %}
{% endif %}
{% include '5.footer.html' %}
{% endblock content %}

__ONETEMP__homepage.html

{% extends "base.html" %} 
{% load static %}
{% block title %}Project Home Page{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<div class="container-fluid mx-2 ">
    <div class="row">
        <div class="col-md-12 d-flex justify-content-start  align-items-center">
            <b>{{project.title}} Project's HomePage</b>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 d-flex justify-content-start  align-items-center">
            <b>Homepage</b>    
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Summary</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Visual-Board</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Timeline</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Release</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Issues</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;      
            <a href="{% url 'navbar_project' %}">Reports</a>
        </div>
        <div class="col-md-4 d-flex justify-content-end align-items-center">            
            &nbsp;&nbsp;
            <a href="{% url 'add_project' %}" class="btn btn-success">Add New Project</a>
            &nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">
                List Projects
            </a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="{% url 'restore_projects' %}">
                Restore
            </a>
        </div>
    </div>
    <form action="" method='POST' class='form'>
        {% csrf_token %}   

    </form>
    <div class="row">
        <div class="col-md-12">
            <a href="{% url 'list_newtodolistitems' backlog.id %}">{{backlog}}</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <h4>Backlog Details</h4>
        </div>
        <div class="col-md-4">
            <h4>Summary</h4>
            <p>Vision, Mission, Value Statement</p>
            <b>Roadmap</b>
        </div>
        <div class="col-md-4">
            <h4>Team</h4>
        </div>
    </div>
</div>

{% include '../../../../5.footer.html' %}
{% endblock content %}

restore___ONETEMP__.html

{% extends "base.html" %} 
{% load static %}
{% block title %}Restore Project{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <h5>Restore Project</h5>
        </div>
        <div class="col-md-4"></div>
    </div>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <form action="" method='POST' class='form'>
                {% csrf_token %}
                <div class="form__group">
                <p>Do you want to restore this Project <b>{{project}}</b>?</p>
                </div>
                <div class="for__group">
                <input type="submit" value='Confirm Restore' class='btn btn-success'>
                </div>
                </form>
        </div>
        <div class="col-md-4"></div>
    </div>
</div>
{% endblock content %}

restore___ONETEMP__.html

{% extends "base.html" %} 
{% load static %}
{% load crispy_forms_tags %}
{% block title %}Projects{% endblock title %} 
{% block content %}
{% if user.is_authenticated %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$( function() {
  // on load hide the datetime details and show when checkbox selected

  $('td:nth-child(6),th:nth-child(6)').hide();
  $('td:nth-child(7),th:nth-child(7)').hide();
  $('td:nth-child(8),th:nth-child(8)').hide();
  $('td:nth-child(9),th:nth-child(9)').hide();
  $('td:nth-child(10),th:nth-child(10)').hide();
  $('td:nth-child(11),th:nth-child(11)').hide();
  $('td:nth-child(12),th:nth-child(12)').hide();
  $('td:nth-child(13),th:nth-child(13)').hide();
  $(".show_hide_details").click(function (event) {
        var checkbox_data = $(this).attr('id');
        var checkbox_this = $(this);
        if ($(this).prop('checked')==true){ 
          //alert("show");
            $('td:nth-child(5),th:nth-child(5)').show();
            $('td:nth-child(6),th:nth-child(6)').show();
            $('td:nth-child(7),th:nth-child(7)').show();
            $('td:nth-child(8),th:nth-child(8)').show();
            $('td:nth-child(9),th:nth-child(9)').show();
            $('td:nth-child(10),th:nth-child(10)').show();
            $('td:nth-child(11),th:nth-child(11)').show();
            $('td:nth-child(12),th:nth-child(12)').show();
        } else {
            $('td:nth-child(5),th:nth-child(5)').hide();
            $('td:nth-child(6),th:nth-child(6)').hide();
            $('td:nth-child(7),th:nth-child(7)').hide();
            $('td:nth-child(8),th:nth-child(8)').hide();
            $('td:nth-child(9),th:nth-child(9)').hide();
            $('td:nth-child(10),th:nth-child(10)').hide();
            $('td:nth-child(11),th:nth-child(11)').hide();
            $('td:nth-child(12),th:nth-child(12)').hide();
        }
  });
});
</script>

<form action="{% url 'bulk_restore_deleted_projects' %}" name="" method="POST">
{% csrf_token %}
<div class="container-fluid">   
    <div class="row">
        <div class="col-md-12 d-flex justify-content-start">
            <b>Project Page</b>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 d-flex justify-content-start align-items-center">
            <b>Restore deleted Project(s)</b>
            &nbsp;&nbsp;           
            <input type="checkbox" name='show_hide' class='show_hide_details'>&nbsp;&nbsp;<font size='-2'>Show Details</font>
        </div>
        <div class="col-md-8 d-flex justify-content-end align-items-center">
            Total: {{newtodolist_count}} Project(s)&nbsp;&nbsp;
            <b>Display:</b>&nbsp;&nbsp;
            <select name="pagination" id="pagination" onchange="this.form.submit()">
                <option value="none">-Select-</option>
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="150">150</option>
                <option value="200">200</option>
                <option value="all">All</option>
            </select>
            &nbsp;&nbsp;
            <b>Bulk:</b>&nbsp;&nbsp;
            <select name="bulk_project_ops" id="bulk_project_ops" onchange="this.form.submit()">
                <option value="none">-Select-</option>
                <option value="bulk_restore">Restore</option>                
                <option value="bulk_not_done">Not Done</option>
                <option value="bulk_delete_permanently">Delete</option>
            </select>
            &nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">List Projects</a>&nbsp;&nbsp;

            <a href="{% url 'add_project' %}" class="btn btn-success">Add New Project</a>
            &nbsp;&nbsp;
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <tr>
                    <th>
                        <input type="checkbox" name="project_box" id="{{project.id}}" onclick='checkUncheck(this)'>
                    </th>
                    <th>#</th>
                    <th>ID</th>
                    <th>Project Name</th>
                    <th>Description</th>

                    <th>Type</th>
                    <th>Priority</th>
                    <th>State</th>
                    <th>Start Date</th>

                    <th>End Date</th>
                    <th>Progress</th>
                    <th>Done</th>
                    <th>Note</th>  

                    <th>Action</th>
                </tr>
                {% for todo in newtodolist %}
                <tr>
                    <td>
                        <input type="checkbox" name="restore_project_box" id="{{todo.id}}" value="{{todo.id}}">
                    </td>
                    <td>{{forloop.counter}}</td>
                    <td>{{todo.id}}</td>
                    <td>{{todo.title}}</td>
                    <td>{{todo.description}}</td>
                    <td>{{todo.project_type}}</td>
                    <td>{{todo.project_priority}}</td>
                    <td>{{todo.project_state}}</td>
                    <td>{{todo.start_date}}</td>
                    <td>{{todo.end_date}}</td>
                    <td>{{todo.progress}}</td>
                    <td>{{todo.done}}</td>
                    <td>{{todo.current_state}}</td>                    
                    <td>
                        <a href="{% url 'view_project' todo.id %}">View</a>&nbsp;
                        <a href="{% url 'edit_project' todo.id %}">Edit</a>&nbsp;
                        <a href="{% url 'restore_project' todo.id %}">Restore</a>&nbsp;
                        <a href="{% url 'copy_project' todo.id %}">Copy</a>&nbsp;
                        <!--
                        <select name="project_action" id="">
                            <option value="none">-Select-</option>
                            <option value="view_project">View</option>
                            <option value="edit_project">Edit</option>
                            <option value="delete_project">Delete</option>
                            <option value="copy_project">Copy</option>
                        </select>
                        -->
                    </td>
                </tr>
                {% endfor %}
            </table>
        </div>
    </div>
</div>
</form>
<script>
function checkUncheck(checkBox) {
    get = document.getElementsByName('restore_project_box');
    for(var i=0; i<get.length; i++) {
        get[i].checked = checkBox.checked;
    }
}
</script>
{% else%}
  {% include 'GUEST_USER.html' %}
{% endif %}
{% include '5.footer.html' %}
{% endblock content %}

view___ONETEMP__.html

{% extends "base.html" %} 
{% load static %}
{% block title %}Add Project{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<div class="container-fluid">
    <div class="row">
        <div class="col-md-9 d-flex justify-content-start align-items-center">
            <b>View Project Details</b>
        </div>
        <div class="col-md-3 d-flex justify-content-end align-items-center">
            <a href="{% url 'edit_project' project.id %}">Edit Project</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="{% url 'navbar_project' %}">Project List</a>
        </div>
    </div>
    <div class="columns">
        <div class="column is-*">
            <table class="table is-bordered is-paddingless is-marginless mt-0 mb-0">
                <tr>
                    <td>
                        <b>Project ID</b>
                    </td>
                    <td>
                        {{project.id}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Name</b>
                    </td>
                    <td>
                        {{project.title}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Description</b>
                    </td>
                    <td>
                        {{project.description}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Project Type</b>
                    </td>
                    <td>
                        {{project.project_type}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Project State</b>
                    </td>
                    <td>
                        {{project.project_state}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Project Priority</b>
                    </td>
                    <td>
                        {{project.project_priority}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Backlog Template</b>
                    </td>
                    <td>
                        {{project.work_item_type}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Start Date</b>
                    </td>
                    <td>
                        {{project.start_date}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>End Date</b>
                    </td>
                    <td>
                        {{project.end_date}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Note</b>
                    </td>
                    <td>
                        {{project.current_state}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Progress</b>
                    </td>
                    <td>
                        {{project.progress}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Created At</b>
                    </td>
                    <td>
                        {{project.created_at}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Updated At</b>
                    </td>
                    <td>
                        {{project.updated_at}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Completed At</b>
                    </td>
                    <td>
                        {{project.completed_at}}
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Duration (hours)</b>
                    </td>
                    <td>
                        {{project.duration_in_hours}}
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>


{% include '../../../../5.footer.html' %}
{% endblock content %}

bulk_restore_ops.html

{% extends "base.html" %} 
{% load static %}
{% block title %}Dev Product{% endblock title %} 
{% block content %}
{% include '../../../../1.toplevel.html' %}
{% include '../../../../2.navbar.html' %}
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <a href="{% url 'navbar_project' %}">List of Projects</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9">
            <h5>Bulk Operations :: Restore Deleted Project(s)</h5>
            {% for id in selected_project_ids %}
                <b>Project ID: {{id}}</b><br>
            {% endfor %}
            <p>has been marked {{bulk_ops}}.</p>
        </div>
    </div>
</div>
{% endblock content %}

