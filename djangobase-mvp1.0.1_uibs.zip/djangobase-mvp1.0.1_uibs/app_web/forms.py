from django import forms
from mptt.forms import TreeNodeChoiceField
from .models import *
from django.shortcuts import  get_object_or_404
from app_todolist.models import * 

class PlannerForm(forms.ModelForm):    
    title = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))
    description = forms.CharField(widget=forms.Textarea(attrs={'rows': 5, 'cols': 50}), required=False)
   
    done = forms.BooleanField(required=False)

    class Meta:
        model = Planner
        fields = [ 'title','description',   'done' ]

class UserPreferenceForm(forms.ModelForm):    
    scope = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))
    setting = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))
    preference = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))

    class Meta:
        model = UserPreference
        fields = [ 'scope', 'setting', 'preference' ]


class ProjectForm(forms.ModelForm):    
    title = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))
    description = forms.CharField(widget=forms.Textarea(attrs={'rows': 5, 'cols': 50}), required=False)
    project_type = forms.ModelChoiceField(queryset=ProjectType.objects.filter(active=True), empty_label='Select Project Type', required=False)
    project_state = forms.ModelChoiceField(queryset=ProjectState.objects.filter(active=True), empty_label='Select Project State', required=False)
    project_priority = forms.ModelChoiceField(queryset=ProjectPriority.objects.filter(active=True), empty_label='Select Project Priority', required=False)
    work_item_type = TreeNodeChoiceField(queryset=TypeList.objects.filter(active=True), empty_label="Select a Work Item Type")
    start_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    progress = forms.DecimalField(max_digits=3, decimal_places=2, required=False)    
    current_state = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}), required=False)
    done = forms.BooleanField(required=False)

    class Meta:
        model = Project
        fields = [ 'title','description', 'project_type', 'project_state', 'project_priority', 'work_item_type', 'start_date', 'end_date', 'progress', 'current_state', 'done' ]

class ProductForm(forms.ModelForm):    
    title = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))
    description = forms.CharField(widget=forms.Textarea(attrs={'rows': 5, 'cols': 50}), required=False)
    product_type = forms.ModelChoiceField(queryset=ProductType.objects.filter(active=True), empty_label='Select Product Type', required=False)
    product_state = forms.ModelChoiceField(queryset=ProductState.objects.filter(active=True), empty_label='Select Product State', required=False)
    product_priority = forms.ModelChoiceField(queryset=ProductPriority.objects.filter(active=True), empty_label='Select Product Priority', required=False)
    work_item_type = TreeNodeChoiceField(queryset=TypeList.objects.filter(active=True), empty_label="Select a Work Item Type")
    start_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    progress = forms.DecimalField(max_digits=3, decimal_places=2, required=False)    
    current_state = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}), required=False)
    done = forms.BooleanField(required=False)

    class Meta:
        model = Product
        fields = [ 'title','description', 'product_type', 'product_state', 'product_priority', 'work_item_type',  'start_date', 'end_date', 'progress', 'current_state', 'done' ]



# VSMS forms
class VSMForm(forms.ModelForm):    
    title = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))
    description = forms.CharField(widget=forms.Textarea(attrs={'rows': 5, 'cols': 50}), required=False)
    work_item_type = TreeNodeChoiceField(queryset=TypeList.objects.filter(active=True), empty_label="Select a Work Item Type")

    class Meta:
        model = VSM
        fields = [ 'title','description', 'work_item_type' ]


class VSMS_Steps_Form(forms.ModelForm): 
    title = forms.CharField(widget=forms.TextInput(attrs={'size': '50'}))
    description = forms.CharField(widget=forms.TextInput(attrs={'rows': 5, 'cols': 50}), required=False)
    role = forms.CharField(widget=forms.TextInput(attrs={'size': '25'}))
    value_time = forms.DecimalField(max_digits=9, decimal_places=2, required=False)   
    non_value_time = forms.DecimalField(max_digits=9, decimal_places=2, required=False)   
    percentage_accurate = forms.DecimalField(max_digits=5, decimal_places=2, required=False)   

    class Meta:
        model = VSMS_Steps
        fields = [ 'title','description', 'role', 'value_time', 'non_value_time', 'percentage_accurate', ]




