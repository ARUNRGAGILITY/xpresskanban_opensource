from django.db import models
from django.urls import reverse
from mptt.models import MPTTModel, TreeForeignKey
from django.conf import settings
from django.utils.text import slugify
from django.db.models import Sum, FloatField
from decimal import Decimal
from django.utils import timezone
from django.contrib.auth.models import User
from django.db.models.signals import pre_save
from django.dispatch import receiver
from app_todolist.models import *


class ProjectState(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='projstate')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')

class ProjectPriority(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='projpriority')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')

class ProjectType(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='ptype')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')


class Project(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    work_item_type = models.ForeignKey(TypeList, on_delete=models.SET_NULL, null=True, blank=True)
    project_type = models.ForeignKey(ProjectType, null=True, blank=True, related_name='project_type', on_delete=models.CASCADE)
    project_priority = models.ForeignKey(ProjectPriority, null=True, blank=True, related_name='project_priority', on_delete=models.CASCADE)
    project_state = models.ForeignKey(ProjectState, null=True, blank=True, related_name='project_state', on_delete=models.CASCADE)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    progress = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    current_state = models.TextField(null=True, blank=True, default='')
    done = models.BooleanField(default=False)

    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_in_hours = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='project1')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')

### Common items depends on earlier ###
class VMV(models.Model):
    project = models.OneToOneField(Project, on_delete=models.CASCADE)
    vision = models.TextField(null=True, blank=True, default='')
    mission = models.TextField(null=True, blank=True, default='')
    value = models.TextField(null=True, blank=True, default='')    

    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='vmv')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.vision

    def get_absolute_url(self):
        return reverse('typelist_home')


class ProductState(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='prodstate')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')

class ProductPriority(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='prodpriority')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')

class ProductType(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='prodtype')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('typelist_home')


class Product(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    product_type = models.ForeignKey(ProductType, null=True, blank=True, related_name='product_type', on_delete=models.CASCADE)
    product_priority = models.ForeignKey(ProductPriority, null=True, blank=True, related_name='product_priority', on_delete=models.CASCADE)
    product_state = models.ForeignKey(ProductState, null=True, blank=True, related_name='product_state', on_delete=models.CASCADE)
    work_item_type = models.ForeignKey('app_todolist.TypeList', on_delete=models.SET_NULL, null=True, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    progress = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    current_state = models.TextField(null=True, blank=True, default='')
    done = models.BooleanField(default=False)

    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_in_hours = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='product1')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')
    
### VSM ###
class VSM(models.Model):
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    work_item_type = models.ForeignKey('app_todolist.TypeList', on_delete=models.SET_NULL, null=True, blank=True)
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='vsm1')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')

#### VSM related
class VSMS_Overview(models.Model):
    vsms = TreeForeignKey(NewTodoList, on_delete=models.CASCADE, related_name='vsms_overview')
    trigger =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')
    starting_point = models.TextField(null=True, blank=True, default='')
    end_point = models.TextField(null=True, blank=True, default='')
    demand_rate = models.TextField(null=True, blank=True, default='')
    boundaries_and_limitations = models.TextField(null=True, blank=True, default='')
    improvement_items = models.TextField(null=True, blank=True, default='')
    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='avsms_vsms_overview')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')


#### VSM related
class VSMS_Info(models.Model):
    vsms = TreeForeignKey(NewTodoList, on_delete=models.CASCADE, related_name='vsms_info')
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')

    total_value_time = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_non_value_time = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    end_to_end_time = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    rolled_ca = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    # Add other fields for VSM metrics, such as cycle time, lead time, etc.
    organization_efficiency = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='avsms_vsms_info')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')

class VSMS_Steps(models.Model):
    #info = models.ForeignKey(VSMS_Info, null=True, blank=True, related_name='info_fk', on_delete=models.CASCADE)
    vsms = TreeForeignKey(NewTodoList,  on_delete=models.CASCADE, related_name='vsms_steps')
    title =  models.CharField(max_length=256)
    description = models.TextField(null=True, blank=True, default='')

    role =  models.CharField(max_length=50, null=True, blank=True, default='')

    value_time = models.DecimalField(max_digits=10, decimal_places=2, default=0, )
    non_value_time = models.DecimalField(max_digits=10, decimal_places=2, default=0, )
    percentage_accurate = models.DecimalField(max_digits=10, decimal_places=2, default=1, )

    position = models.PositiveIntegerField(default=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='avsms_steps')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')
    
   
class Planner(models.Model):
    title =  models.CharField(max_length=256)
    who = models.CharField(max_length=100,null=True, blank=True, default='')
    description = models.TextField(null=True, blank=True, default='')  
    done = models.BooleanField(default=False)
    position = models.PositiveIntegerField(default=1000)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_in_hours = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='planner1')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todlist_home')
    
class UserPreference(models.Model):
    userid = models.CharField(max_length=50)
    scope =  models.CharField(max_length=256)
    setting =  models.CharField(max_length=256)
    preference =  models.CharField(max_length=256)    

    done = models.BooleanField(default=False)
    position = models.PositiveIntegerField(default=1000)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    active = models.BooleanField(default=True, null=True, blank=True)
    deleted = models.BooleanField(default=True, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='ups')

    class Meta:
        ordering = ['position']

    def __str__(self):
        return self.userid

    def get_absolute_url(self):
        return reverse('todlist_home')