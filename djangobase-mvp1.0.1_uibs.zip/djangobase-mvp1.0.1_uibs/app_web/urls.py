from django.urls import path, include
from .views.navbar_views import *
from .views.vsm_views import *
from .views.exp_views import *
from .views.mvp_views import *

urlpatterns = [
    path('navbar_home', navbar_home, name="navbar_home"),
    path('navbar_todolist', navbar_todolist, name="navbar_todolist"),

    # mvp served by mvp_views.py and /mvp templates
    path('mvp_homepage', mvp_homepage, name="mvp_homepage"),

    # planner from exp
    path('my_planner', my_planner, name="my_planner"),
    path('my_planner_cards', my_planner_cards, name="my_planner_cards"),
    path('ajaxupdate_my_planner', ajaxupdate_my_planner, name="ajaxupdate_my_planner"),
    path('sorted_my_planner',my_planner_sorted, name='my_planner_sorted'),
    path('my_planner_done_update/',my_planner_done_update, name='my_planner_done_update'),
    path('delete_my_planner_todo/<int:pk>', delete_my_planner_todo, name="delete_my_planner_todo"),
    path('clear_my_planner_todo/<int:pk>', clear_my_planner_todo, name="clear_my_planner_todo"),
    path('ajaxupdate_set_user_preference/', ajaxupdate_set_user_preference, name="ajaxupdate_set_user_preference"),
    path('ops_my_planner', ops_my_planner, name="ops_my_planner"),
    path('restore_page_my_planner', restore_page_my_planner, name="restore_page_my_planner"),    
    path('ops_restore_my_planner', ops_restore_my_planner, name="ops_restore_my_planner"),

    # define
    path('navbar_project', navbar_project, name="navbar_project"),
    path('add_project', add_project, name="add_project"),
    path('ops_project', ops_project, name="ops_project"),
    path('view_project/<int:pk>', view_project, name="view_project"),
    path('project_homepage/<int:pk>', project_homepage, name="project_homepage"),
    path('edit_project/<int:pk>', edit_project, name="edit_project"),
    path('delete_project/<int:pk>', delete_project, name="delete_project"),
    path('restore_project/<int:pk>', restore_project, name="restore_project"),
    path('copy_project/<int:pk>', copy_project, name="copy_project"),
    path('restore_projects', restore_projects, name="restore_projects"),
    path('bulk_restore_deleted_projects', bulk_restore_deleted_projects, name="bulk_restore_deleted_projects"),
    path('sorted_project',project_sorted, name='sorted_project'),

    path('navbar_product', navbar_product, name="navbar_product"),
    path('navbar_service', navbar_service, name="navbar_service"),
    path('navbar_solution', navbar_solution, name="navbar_solution"),
    path('navbar_organization', navbar_organization, name="navbar_organization"),

    # product
    path('ops_product', ops_product, name="ops_product"),
    path('sorted_product',product_sorted, name='sorted_product'),
    path('add_product', add_product, name="add_product"),
    path('view_product/<int:pk>', view_product, name="view_product"),
    path('product_homepage/<int:pk>', product_homepage, name="product_homepage"),
    path('edit_product/<int:pk>', edit_product, name="edit_product"),
    path('delete_product/<int:pk>', delete_product, name="delete_product"),
    path('restore_product/<int:pk>', restore_product, name="restore_product"),
    path('copy_product/<int:pk>', copy_product, name="copy_product"),
    path('restore_products', restore_products, name="restore_products"),
    path('bulk_restore_deleted_products', bulk_restore_deleted_products, name="bulk_restore_deleted_products"),
    # learn
    path('navbar_learn_agile', navbar_learn_agile, name="navbar_learn_agile"),
    path('navbar_learn_lean', navbar_learn_lean, name="navbar_learn_lean"),
    path('navbar_learn_systems', navbar_learn_systems, name="navbar_learn_systems"),
    path('navbar_learn_agileintro', navbar_learn_agileintro, name="navbar_learn_agileintro"),


    # VSM
    path('navbar_vsm', navbar_vsm, name="navbar_vsm"),
    path('add_vsm', add_vsm, name="add_vsm"),
    path('ops_vsm', ops_vsm, name="ops_vsm"),
    path('view_vsm/<int:pk>', view_vsm, name="view_vsm"),
    path('vsm_homepage/<int:pk>', vsm_homepage, name="vsm_homepage"),
    path('edit_vsm/<int:pk>', edit_vsm, name="edit_vsm"),
    path('delete_vsm/<int:pk>', delete_vsm, name="delete_vsm"),
    path('restore_vsm/<int:pk>', restore_vsm, name="restore_vsm"),
    path('copy_vsm/<int:pk>', copy_vsm, name="copy_vsm"),
    path('restore_vsms', restore_vsms, name="restore_vsms"),
    path('bulk_restore_deleted_vsms', bulk_restore_deleted_vsms, name="bulk_restore_deleted_vsms"),
    path('sorted_vsm',vsm_sorted, name='sorted_vsm'),

    # VSMS steps
    path('main_vsms_steps/<int:vsm_id>', main_vsms_steps, name="main_vsms_steps"),
    path('visual_main_vsms_steps/<int:vsm_id>', visual_main_vsms_steps, name="visual_main_vsms_steps"),
    path('ops_vsms_steps', ops_vsms_steps, name="ops_vsms_steps"),
    path('sorted_vsms_steps',vsms_steps_sorted, name='sorted_vsms_steps'),
    path('add_vsms_steps/<int:vsm_id>', add_vsms_steps, name="add_vsms_steps"),
    path('view_vsms_steps/<int:pk>', view_vsms_steps, name="view_vsms_steps"),
    path('edit_vsms_steps/<int:pk>', edit_vsms_steps, name="edit_vsms_steps"),
    path('delete_vsms_steps/<int:pk>', delete_vsms_steps, name="delete_vsms_steps"),
    path('copy_vsms_steps/<int:pk>', copy_vsms_steps, name="copy_vsms_steps"),
    path('restore_vsms_steps', restore_vsms_steps, name="restore_vsms_steps"),





    
]
