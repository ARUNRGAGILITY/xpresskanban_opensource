from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from ..models import *
from ..forms import *
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from mptt.exceptions import InvalidMove
from copy import copy
from copy import deepcopy
from mptt.exceptions import InvalidMove
from mptt.utils import tree_item_iterator
from mptt.templatetags.mptt_tags import cache_tree_children
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

# navbar_product
#

@login_required(login_url='login')   
def navbar___ELEMENT__(request):
    context = {'page': '__ELEMENT__'}
    pagination_on = False
    # here we list all projects
    __element__ = __ELEMENT__.objects.filter(active=True).order_by('position')
    __element___count = __element__.count()
    form = __ELEMENT__Form(request.user)
    # pagination
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = __element__
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(__element__, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)

    context = {'page': '__ELEMENT__', '__element__': __element__,'form':form, '__element___count': __element___count,
                'pagination':selected_pagination, 'paginated_items': paginated_items, 
                'pagination_on': pagination_on}
    return render(request, '__TEMPLATEPATH__/__element__navbar.html', context)

@login_required(login_url='login')
def __element___homepage(request, pk):
    form = __ELEMENT__Form()
    __element__ = get_object_or_404(__ELEMENT__, pk=pk)
    backlog = get_object_or_404(__CORE_HSDB__, __element__=__element__)
    object_items = __element__
    object_items_count = __element__.__element___backlog.filter(active=True).count()
    if request.method == 'POST':
        print(f"Received PRODUCT HOME PAGE >>>> FORM")
    context = {'object_items': object_items, 'form': form, 'backlog_id': backlog.id,
               'backlog': backlog,
               'core_hsdb_parent_id ': pk, 'object_items_count': object_items_count, 
               '__element__': __element__, }
    return render(request, '__TEMPLATEPATH__/__element___homepage.html', context)

##### product
@login_required(login_url='login')
def ops___element__(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_object_ids = request.POST.getlist('object_box')        
        bulk_ops = form_data.get('bulk_object_ops')
        pagination = form_data.get('pagination')
        if bulk_ops == "bulk_delete":
            for id in selected_object_ids:
                __ELEMENT__.objects.filter(id=id).update(active=False, deleted=False,  author=request.user)
        elif bulk_ops == "bulk_done":
            for id in selected_object_ids:
                __ELEMENT__.objects.filter(id=id).update(done=True,  author=request.user)
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 
                   'selected_object_ids':selected_object_ids}
    return render(request, '__TEMPLATEPATH__/__element___bulk_ops.html', context)

@login_required(login_url='login')
def restore___element__(request):
    context = {'page': 'Restore __element__'}
    # here we list all projects deleted and restore
    newtodolist = Product.objects.filter(active=False, deleted=False).order_by('position')
    newtodolist_count = newtodolist.count()
    form = ProductForm(request.user)
    if request.method == 'POST':
        form = ProductForm(request.user, request.POST)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            todo_count = newtodolist.count()
            return redirect('navbar_product')
        else:
            print(f"form is invalid {form}")
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return render(request, 'general_templates/navbar/define/product/restore_products.html', context)


@login_required(login_url='login')
def product_sorted(request):
    if request.method == 'POST':
        ajax_data = request.POST['sorted_list_data']
        new_data = ajax_data.replace("[",'')
        new_data = new_data.replace("]",'')
        sorted_list = new_data.split(",")
        seq = 1
        for item in sorted_list:
            str = item.replace('"','')
            position = str.split('_')
            Product.objects.filter(pk=position[0]).update(position=seq)
            seq = seq + 1
        return render(request, 'general_templates/navbar/define/navbar_product.html', {'ajax_data': ajax_data})

@login_required(login_url='login')
def bulk_restore_deleted_products(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_product_ids = request.POST.getlist('restore_product_box')        
        bulk_ops = form_data.get('bulk_product_ops')
        if bulk_ops == "bulk_restore":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(active=True,  author=request.user)
        elif bulk_ops == "bulk_not_done":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(done=False,  author=request.user)
        elif bulk_ops == "bulk_delete_permanently":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(active=False, deleted=True,  author=request.user)
        pagination = form_data.get('pagination')
        print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 'selected_product_ids':selected_product_ids}
    return render(request, 'general_templates/navbar/define/product/bulk_restore_ops.html', context)

# add product
@login_required(login_url='login')
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.instance.author = request.user
            product = form.save()
            #######################################
            if not NewTodoList.objects.filter(product=product).exists():
                # Create a related Backlog entry only if it doesn't exist
                backlog_title = f"{product.title} Backlog"
                backlog = NewTodoList.objects.create(title=backlog_title, 
                            product=product, active=True, author=request.user,
                            workitemtype=form.cleaned_data['work_item_type'])

            # Handle form submission success
            return redirect('navbar_product')
    else:
        form = ProductForm()
    
    context = {'page': 'Add Product', 'form': form}
    return render(request, 'general_templates/navbar/define/product/add_product.html', context)

@login_required(login_url='login')
def view_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    context = {'product': product}
    return render(request, 'general_templates/navbar/define/product/view_product.html', context)

@login_required(login_url='login')
def edit_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    form = ProductForm(instance=product)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            return redirect('navbar_product')
    else:
        form = ProductForm(instance=product)
    context = {'form': form, 'product': product}
    return render(request, 'general_templates/navbar/define/product/edit_product.html', context)

@login_required(login_url='login')
def delete_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    context = {'product': product}
    if request.method == 'POST':
        Product.objects.filter(id=pk).update(active=False,  author=request.user)
        return redirect('navbar_product')
    return render(request, 'general_templates/navbar/define/product/delete_product.html', context)

@login_required(login_url='login')
def restore_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    context = {'product': product}
    if request.method == 'POST':
        Product.objects.filter(id=pk).update(active=True,  author=request.user)
        return redirect('restore_products')
    return render(request, 'general_templates/navbar/define/product/restore_product.html', context)

@login_required(login_url='login')
def copy_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    new_product = Product()
    new_product.title = product.title + " (Copy)"
    new_product.description = product.description
    new_product.product_type = product.product_type
    new_product.product_priority = product.product_priority
    new_product.product_state = product.product_state
    new_product.start_date = product.start_date
    new_product.end_date = product.end_date
    new_product.current_state = product.current_state

    new_product.save()
    new_product_id = new_product.id
    context = {'product': product, 'new_product_id':new_product_id, 'new_product':new_product}
    return render(request, 'general_templates/navbar/define/product/copy_product.html', context)
