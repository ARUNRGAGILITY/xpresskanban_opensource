from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from ..models import *
from ..forms import *
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from mptt.exceptions import InvalidMove
from copy import copy
from copy import deepcopy
from mptt.exceptions import InvalidMove
from mptt.utils import tree_item_iterator
from mptt.templatetags.mptt_tags import cache_tree_children
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from app_todolist.forms import *
from django.utils.html import strip_tags
import json

@login_required(login_url='login')
def my_planner(request):    
    # send the userpreference details
    user_preferences = UserPreference.objects.filter(userid=request.user.id, scope='my_planner').values('setting', 'preference')
    list_user_preferences = list(user_preferences)
    user_preferences_json = json.dumps(list(user_preferences))
    #newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('position')[:target_count]
    recent_first = find_preference('recent_first', list_user_preferences)
    sort_by_aging = find_preference('sort_by_aging', list_user_preferences)
    if sort_by_aging == "yes":
        print(f"SORT BY AGING")
        newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('created_at')
    elif recent_first == "yes":
        print(f"SORT BY RECENT FIRST")
        newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('-created_at')
    else:
        print(f"SORT BY position")
        newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('position')
    
    newtodolist_count = newtodolist.count()   
    form = PlannerForm(request.user)
    # pagination
    pagination_on = False
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)

    if request.method == 'POST':
        form = PlannerForm(request.POST)
        if form.is_valid():
            # get the user preference and accordingly create
            add_top = find_preference('add_top', list_user_preferences)
            if add_top == "yes":
                form.instance.position = 0
            form.instance.title = strip_tags(form.cleaned_data['title'])
            form.instance.author = request.user
            form.save()
            newtodolist_count = newtodolist.count()
            return redirect('my_planner')
        else:
            print(f"form is invalid {form}")
    context = {'user_preferences_json': user_preferences_json, 
               'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count,
                'pagination':selected_pagination, 'paginated_items': paginated_items, 
                'pagination_on': pagination_on}
    return render(request, 'app_web/exp/my_planner.html', context)

@login_required(login_url='login')
def my_planner_cards(request):    
    # send the userpreference details
    user_preferences = UserPreference.objects.filter(userid=request.user.id, scope='my_planner').values('setting', 'preference')
    list_user_preferences = list(user_preferences)
    user_preferences_json = json.dumps(list(user_preferences))
    #newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('position')[:target_count]
    recent_first = find_preference('recent_first', list_user_preferences)
    sort_by_aging = find_preference('sort_by_aging', list_user_preferences)
    if sort_by_aging == "yes":
        print(f"SORT BY AGING")
        newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('created_at')
    elif recent_first == "yes":
        print(f"SORT BY RECENT FIRST")
        newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('-created_at')
    else:
        print(f"SORT BY position")
        newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('position')

    # cards 
    columns_per_row = 6
    rows = [newtodolist[i:i + columns_per_row] for i in range(0, len(newtodolist), columns_per_row)]
    

    newtodolist_count = newtodolist.count()   
    form = PlannerForm(request.user)
    # pagination
    pagination_on = False
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)

    if request.method == 'POST':
        form = PlannerForm(request.POST)
        if form.is_valid():
            # get the user preference and accordingly create
            add_top = find_preference('add_top', list_user_preferences)
            if add_top == "yes":
                form.instance.position = 0
            form.instance.title = strip_tags(form.cleaned_data['title'])
            form.instance.author = request.user
            form.save()
            newtodolist_count = newtodolist.count()
            return redirect('my_planner_cards')
        else:
            print(f"form is invalid {form}")
    context = {'rows': rows, 'user_preferences_json': user_preferences_json, 
               'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count,
                'pagination':selected_pagination, 'paginated_items': paginated_items, 
                'pagination_on': pagination_on}
    return render(request, 'app_web/exp/my_planner_cards.html', context)

# Function to find the preference based on setting
def find_preference(setting, user_preferences):
    preference_obj = next((item for item in user_preferences if item['setting'] == setting), None)
    return preference_obj['preference'] if preference_obj else 'no'

@login_required(login_url='login')
def ajaxupdate_my_planner(request):
    print(f">>>>> ajaxupdate_my_planner")
    if request.method == 'POST':
        print("AJAX CHECKBOX METHOD TEST")
        ajax_data = request.POST['checkbox_data']
        checkbox_details = ajax_data.split('_')
        checkbox_id = checkbox_details[0]
        checkbox_position = checkbox_details[1]
        checkbox_status = strip_tags(checkbox_details[2])
        print(f">>>>>>>>>> id{checkbox_id} pos {checkbox_position} content {checkbox_status}")
        obj = Planner.objects.filter(id=checkbox_id).update(title=checkbox_status)

        response_data = {}
        response_data['result'] = obj

        return JsonResponse(response_data)
    context = {}
    return render(request, 'app_web/exp/my_planner.html', context)

@login_required(login_url='login')
def my_planner_sorted(request):
    if request.method == 'POST':
        print(f">>>>> ajax LIST sorted")
        ajax_data = request.POST['sorted_list_data']
        print(f">>>>> ajax LIST sorted {ajax_data}")
        new_data = ajax_data.replace("[",'')
        new_data = new_data.replace("]",'')
        sorted_list = new_data.split(",")
        seq = 1
        for item in sorted_list:
            str = item.replace('"','')
            position = str.split('_')
            Planner.objects.filter(pk=position[0]).update(position=seq)
            seq = seq + 1
        return render(request, 'app_web/exp/my_planner.html', {'ajax_data': ajax_data})

@login_required(login_url='login')
def my_planner_done_update(request):
    if request.method == 'POST':
        print("AJAX CHECKBOX METHOD TEST")
        ajax_data = request.POST['checkbox_data']
        checkbox_details = ajax_data.split('_')
        checkbox_id = checkbox_details[0]
        checkbox_position = checkbox_details[1]
        checkbox_status = checkbox_details[2]
        db_status = False
        todolist_item = None
        if checkbox_status == 'done':
            db_status = True
        Planner.objects.filter(pk=checkbox_id).update(done=db_status, author=request.user, completed_at=timezone.now())
        todolist_item = Planner.objects.get(pk=checkbox_id)
        print(f"CHECKBOX DETAILS GOT: ID>>>{checkbox_id} POS>>>{checkbox_position} STATUS>>>{checkbox_status}")
        print(f"{todolist_item.updated_at}>>>>> UPDATED TIME")
        response_data = {}
        response_data['result'] = None

        return JsonResponse(response_data)
    
@login_required(login_url='login')
def delete_my_planner_todo(request, pk):
    form = PlannerForm(request.user)
    Planner.objects.filter(id=pk).update(active=False,  author=request.user)
    newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('position')
    newtodolist_count = newtodolist.count()
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return redirect('my_planner') 

@login_required(login_url='login')
def clear_my_planner_todo(request, pk):
    form = PlannerForm(request.user)
    Planner.objects.filter(id=pk).update(title='',  author=request.user)
    newtodolist = Planner.objects.filter(active=True, author=request.user).order_by('position')
    newtodolist_count = newtodolist.count()
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return redirect('my_planner')

@login_required(login_url='login')
def ajaxupdate_set_user_preference(request):
    print(f">>>>> ajax_update_user_preference")
    obj = None
    if request.method == 'POST':
        print("AJAX CHECKBOX METHOD TEST")
        ajax_data = request.POST['checkbox_data']
        print(f"AJAX CHECKBOX METHOD TEST ==> {ajax_data}")
        checkbox_details = ajax_data.split('/')
        checkbox_id = checkbox_details[0]
        checkbox_scope = checkbox_details[1]
        checkbox_setting = strip_tags(checkbox_details[2])
        checkbox_preference = strip_tags(checkbox_details[3])
        print(f">>>>>>>>>> id{checkbox_id} scope {checkbox_scope} setting {checkbox_setting} preference {checkbox_preference}")
        userobj = User.objects.get(id=checkbox_id)

        try:
            user_preference = UserPreference.objects.get(userid=checkbox_id, scope=checkbox_scope, setting=checkbox_setting)
            user_preference.preference = checkbox_preference
            user_preference.save()            
            return JsonResponse({'status': 'success', 'message': 'Preference updated successfully.'})
        except UserPreference.DoesNotExist:            
            UserPreference.objects.create(userid=checkbox_id, scope=checkbox_scope, setting=checkbox_setting, preference=checkbox_preference)
            return JsonResponse({'status': 'success', 'message': 'Preference created successfully.'})
        except Exception as e:            
            return JsonResponse({'status': 'error', 'message': str(e)})
    context = {}
    return render(request, 'app_web/exp/my_planner.html', context)

# ops of the planner
@login_required(login_url='login')
def ops_my_planner(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_object_ids = request.POST.getlist('todo_box')   
        print(f">>>>> {selected_object_ids} for the bulk planner ops")     
        bulk_ops = form_data.get('ops')
        if bulk_ops == "move_to_top":
            for id in selected_object_ids:
                Planner.objects.filter(id=id).update(position=0,  author=request.user)
        if bulk_ops == "move_to_bottom":
            for id in selected_object_ids:
                Planner.objects.filter(id=id).update(position=2000,  author=request.user)
        elif bulk_ops == "delete":
            for id in selected_object_ids:
                Planner.objects.filter(id=id).update(active=False, deleted=False,  author=request.user)
        elif bulk_ops == "clear":
            for id in selected_object_ids:
                Planner.objects.filter(id=id).update(title='',  author=request.user)
        context = {'bulk_ops': bulk_ops, 'selected_object_ids':selected_object_ids}
    return render(request, 'app_web/exp/ops_my_planner.html', context)


# restore related
@login_required(login_url='login')
def restore_page_my_planner(request):
    # send the userpreference details
    user_preferences = UserPreference.objects.filter(userid=request.user.id, scope='my_planner').values('setting', 'preference')
    list_user_preferences = list(user_preferences)
    print(f">>>>>> {user_preferences} as list {list_user_preferences}")
    user_preferences_json = json.dumps(list(user_preferences))
    context = {'page': 'Restore Planner Todo'}
    # here we list all projects deleted and restore
    newtodolist = Planner.objects.filter(active=False, deleted=False).order_by('position')
    newtodolist_count = newtodolist.count()
    form = PlannerForm(request.user)
    if request.method == 'POST':
        form = PlannerForm(request.user, request.POST)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            todo_count = newtodolist.count()
            return redirect('my_planner')
        else:
            print(f"form is invalid {form}")
    context = {'user_preferences_json': user_preferences_json,'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return render(request, 'app_web/exp/restore_page_my_planner.html', context)

@login_required(login_url='login')
def ops_restore_my_planner(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_object_ids = request.POST.getlist('todo_box')   
        print(f">>>>> {selected_object_ids} for the bulk planner ops")     
        bulk_ops = form_data.get('ops')
        if bulk_ops == "restore":
            for id in selected_object_ids:
                Planner.objects.filter(id=id).update(active=True, deleted=False,  author=request.user)
        elif bulk_ops == "delete":
            for id in selected_object_ids:
                Planner.objects.filter(id=id).update(active=False, deleted=True,  author=request.user)
        context = {'bulk_ops': bulk_ops, 'selected_object_ids':selected_object_ids}
    return redirect('my_planner')
