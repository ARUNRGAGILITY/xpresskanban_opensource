from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from ..models import *
from ..forms import *
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from mptt.exceptions import InvalidMove
from copy import copy
from copy import deepcopy
from mptt.exceptions import InvalidMove
from mptt.utils import tree_item_iterator
from mptt.templatetags.mptt_tags import cache_tree_children
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

@login_required(login_url='login')
def navbar_home(request):
    context = {'page': 'HomePage'}
    return render(request, 'general_templates/navbar/navbar_home.html', context)

@login_required(login_url='login')
def navbar_todolist(request):
    context = {'page': 'Todo List'}
    return render(request, 'general_templates/navbar/navbar_todolist.html', context)

@login_required(login_url='login')
def navbar_project(request):
    context = {'page': 'Project'}
    
    # here we list all projects
    newtodolist = Project.objects.filter(active=True).order_by('position')
    newtodolist_count = newtodolist.count()
    form = ProjectForm(request.user)
    # pagination
    pagination_on = False
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)
    
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 'pagination':selected_pagination, 'paginated_items': paginated_items, 'pagination_on': pagination_on}
    return render(request, 'general_templates/navbar/define/project/list_projects.html', context)

@login_required(login_url='login')
def restore_projects(request):
    context = {'page': 'Restore Projects'}
    # here we list all projects deleted and restore
    newtodolist = Project.objects.filter(active=False, deleted=False).order_by('position')
    newtodolist_count = newtodolist.count()
    form = ProjectForm(request.user)
    if request.method == 'POST':
        form = ProjectForm(request.user, request.POST)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            todo_count = newtodolist.count()
            return redirect('navbar_project')
        else:
            print(f"form is invalid {form}")
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return render(request, 'general_templates/navbar/define/project/restore_projects.html', context)


@login_required(login_url='login')
def add_project(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():

            form.instance.author = request.user
            project = form.save()
            #######################################
            if not NewTodoList.objects.filter(project=project).exists():
                # Create a related Backlog entry only if it doesn't exist
                backlog_title = f"{project.title} Backlog"
                backlog = NewTodoList.objects.create(title=backlog_title, 
                            project=project, active=True, author=request.user,
                            workitemtype=form.cleaned_data['work_item_type'])


            
            # Handle form submission success
            return redirect('navbar_project')
    else:
        form = ProjectForm()
    
    context = {'page': 'Add Project', 'form': form}
    return render(request, 'general_templates/navbar/define/project/add_project.html', context)

# @login_required(login_url='login')
# def ops_project(request):
#     if request.method == 'POST':
#         form_data = request.POST
#         bulk_ops = form_data.get('bulk_project_ops')
#         pagination = form_data.get('pagination')
#         print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
#         context = {'bulk_ops': bulk_ops, 'pagination': pagination}
#     return render(request, 'general_templates/navbar/define/project/bulk_project_ops.html', context)



@login_required(login_url='login')
def view_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {'project': project}
    return render(request, 'general_templates/navbar/define/project/view_project.html', context)


@login_required(login_url='login')
def project_homepage(request, pk):
    form = ProjectForm()
    project = get_object_or_404(Project, pk=pk)
    backlogs = project.backlogs.all()
    backlog = get_object_or_404(NewTodoList, project=project)
    newtodolistitems = project
    newtodolistitems_count = project.backlogs.filter(active=True).count()
    if request.method == 'POST':
        print(f"Received PROJECT HOME PAGE >>>> FORM")
    context = {'newtodolistitems': newtodolistitems, 'form': form, 'backlog_id': backlog.id,
               'backlog': backlog,
               'todolist_parent_id ': pk, 'newtodolistitems_count': newtodolistitems_count, 'project': project, 'backlogs':backlogs}
    return render(request, 'general_templates/navbar/define/project/project_homepage.html', context)


@login_required(login_url='login')
def edit_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    form = ProjectForm(instance=project)
    if request.method == 'POST':
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            return redirect('navbar_project')
    else:
        form = ProjectForm(instance=project)
    context = {'form': form, 'project': project}
    return render(request, 'general_templates/navbar/define/project/edit_project.html', context)



@login_required(login_url='login')
def delete_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {'project': project}
    if request.method == 'POST':
        Project.objects.filter(id=pk).update(active=False, deleted=False,  author=request.user)
        return redirect('navbar_project')
    return render(request, 'general_templates/navbar/define/project/delete_project.html', context)

@login_required(login_url='login')
def restore_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {'project': project}
    if request.method == 'POST':
        Project.objects.filter(id=pk).update(active=True,  author=request.user)
        return redirect('restore_projects')
    return render(request, 'general_templates/navbar/define/project/restore_project.html', context)

@login_required(login_url='login')
def copy_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    new_project = Project()
    new_project.title = project.title + " (Copy)"
    new_project.description = project.description
    new_project.project_type = project.project_type
    new_project.project_priority = project.project_priority
    new_project.project_state = project.project_state
    new_project.start_date = project.start_date
    new_project.end_date = project.end_date
    new_project.current_state = project.current_state

    new_project.save()
    new_project_id = new_project.id
    #######################################
    if not NewTodoList.objects.filter(project=project).exists():
        # Create a related Backlog entry only if it doesn't exist
        backlog_title = f"{new_project.title} Backlog"
        backlog = NewTodoList.objects.create(title=backlog_title, 
                    project=new_project, active=True, author=request.user,
                    workitemtype=project.work_item_type)
    context = {'project': project, 'new_project_id':new_project_id, 
               'new_project':new_project, 'backlog': backlog}
    return render(request, 'general_templates/navbar/define/project/copy_project.html', context)

@login_required(login_url='login')
def ops_project(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_project_ids = request.POST.getlist('project_box')        
        bulk_ops = form_data.get('bulk_project_ops')
        pagination = form_data.get('pagination')
        bulk_ops = form_data.get('bulk_project_ops')
        if bulk_ops == "bulk_delete":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(active=False, deleted=False,  author=request.user)
        elif bulk_ops == "bulk_done":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(done=True,  author=request.user)
        print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 'selected_project_ids':selected_project_ids}
    return render(request, 'general_templates/navbar/define/project/bulk_project_ops.html', context)

@login_required(login_url='login')
def bulk_restore_deleted_projects(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_project_ids = request.POST.getlist('restore_project_box')        
        bulk_ops = form_data.get('bulk_project_ops')
        if bulk_ops == "bulk_restore":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(active=True,  author=request.user)
        elif bulk_ops == "bulk_not_done":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(done=False,  author=request.user)
        elif bulk_ops == "bulk_delete_permanently":
            for id in selected_project_ids:
                Project.objects.filter(id=id).update(active=False, deleted=True,  author=request.user)
        pagination = form_data.get('pagination')
        print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 'selected_project_ids':selected_project_ids}
    return render(request, 'general_templates/navbar/define/project/bulk_restore_ops.html', context)

@login_required(login_url='login')
def project_sorted(request):
    if request.method == 'POST':
        ajax_data = request.POST['sorted_list_data']
        new_data = ajax_data.replace("[",'')
        new_data = new_data.replace("]",'')
        sorted_list = new_data.split(",")
        seq = 1
        for item in sorted_list:
            str = item.replace('"','')
            position = str.split('_')
            Project.objects.filter(pk=position[0]).update(position=seq)
            seq = seq + 1
        return render(request, 'general_templates/navbar/define/navbar_project.html', {'ajax_data': ajax_data})

@login_required(login_url='login')   
def navbar_product(request):
    context = {'page': 'Product'}
    pagination_on = False
    # here we list all projects
    newtodolist = Product.objects.filter(active=True).order_by('position')
    newtodolist_count = newtodolist.count()
    form = ProductForm(request.user)
    # pagination
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)

    context = {'page': 'Product', 'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 'pagination':selected_pagination, 'paginated_items': paginated_items, 'pagination_on': pagination_on}
    return render(request, 'general_templates/navbar/define/navbar_product.html', context)

@login_required(login_url='login')
def product_homepage(request, pk):
    form = ProductForm()
    product = get_object_or_404(Product, pk=pk)
    backlogs = product.product_backlog.filter(active=True)
    backlog = get_object_or_404(NewTodoList, product=product)
    newtodolistitems = product
    newtodolistitems_count = product.product_backlog.filter(active=True).count()
    if request.method == 'POST':
        print(f"Received PRODUCT HOME PAGE >>>> FORM")
    context = {'newtodolistitems': newtodolistitems, 'form': form, 'backlog_id': backlog.id,
               'backlog': backlog,
               'todolist_parent_id ': pk, 'newtodolistitems_count': newtodolistitems_count, 
               'product': product, 'backlogs':backlogs}
    return render(request, 'general_templates/navbar/define/product/product_homepage.html', context)



@login_required(login_url='login')   
def navbar_service(request):
    context = {'page': 'Service'}
    return render(request, 'general_templates/navbar/define/navbar_service.html', context)

@login_required(login_url='login')   
def navbar_solution(request):
    context = {'page': 'Solution'}
    return render(request, 'general_templates/navbar/define/navbar_solution.html', context)

@login_required(login_url='login')   
def navbar_organization(request):
    context = {'page': 'Organization'}
    return render(request, 'general_templates/navbar/define/navbar_organization.html', context)

@login_required(login_url='login')   
def navbar_learn_agile(request):
    context = {'page': 'Learn Agile'}
    return render(request, 'general_templates/navbar/learn/navbar_learn_agile.html', context)

@login_required(login_url='login')   
def navbar_learn_lean(request):
    context = {'page': 'Learn Lean'}
    return render(request, 'general_templates/navbar/learn/navbar_learn_lean.html', context)

@login_required(login_url='login')   
def navbar_learn_systems(request):
    context = {'page': 'Learn System'}
    return render(request, 'general_templates/navbar/learn/navbar_learn_systems.html', context)

@login_required(login_url='login')   
def navbar_learn_agileintro(request):
    context = {'page': 'Learn Agile Intro'}
    return render(request, 'general_templates/navbar/learn/navbar_learn_agileintro.html', context)

@login_required(login_url='login')   
def navbar_learn_agilefoundations(request):
    context = {'page': 'Learn Agile Foundations'}
    return render(request, 'general_templates/navbar/learn/navbar_learn_agilefoundations.html', context)

##### product
@login_required(login_url='login')
def ops_product(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_product_ids = request.POST.getlist('product_box')        
        bulk_ops = form_data.get('bulk_product_ops')
        pagination = form_data.get('pagination')
        bulk_ops = form_data.get('bulk_product_ops')
        if bulk_ops == "bulk_delete":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(active=False, deleted=False,  author=request.user)
        elif bulk_ops == "bulk_done":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(done=True,  author=request.user)
        print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 'selected_product_ids':selected_product_ids}
    return render(request, 'general_templates/navbar/define/product/bulk_product_ops.html', context)

@login_required(login_url='login')
def restore_products(request):
    context = {'page': 'Restore Products'}
    # here we list all projects deleted and restore
    newtodolist = Product.objects.filter(active=False, deleted=False).order_by('position')
    newtodolist_count = newtodolist.count()
    form = ProductForm(request.user)
    if request.method == 'POST':
        form = ProductForm(request.user, request.POST)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            todo_count = newtodolist.count()
            return redirect('navbar_product')
        else:
            print(f"form is invalid {form}")
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return render(request, 'general_templates/navbar/define/product/restore_products.html', context)


@login_required(login_url='login')
def product_sorted(request):
    if request.method == 'POST':
        ajax_data = request.POST['sorted_list_data']
        new_data = ajax_data.replace("[",'')
        new_data = new_data.replace("]",'')
        sorted_list = new_data.split(",")
        seq = 1
        for item in sorted_list:
            str = item.replace('"','')
            position = str.split('_')
            Product.objects.filter(pk=position[0]).update(position=seq)
            seq = seq + 1
        return render(request, 'general_templates/navbar/define/navbar_product.html', {'ajax_data': ajax_data})

@login_required(login_url='login')
def bulk_restore_deleted_products(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_product_ids = request.POST.getlist('restore_product_box')        
        bulk_ops = form_data.get('bulk_product_ops')
        if bulk_ops == "bulk_restore":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(active=True,  author=request.user)
        elif bulk_ops == "bulk_not_done":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(done=False,  author=request.user)
        elif bulk_ops == "bulk_delete_permanently":
            for id in selected_product_ids:
                Product.objects.filter(id=id).update(active=False, deleted=True,  author=request.user)
        pagination = form_data.get('pagination')
        print(f">>>>>>>>>>>.FORM. {bulk_ops} is bulk_ops, pagination {pagination}")
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 'selected_product_ids':selected_product_ids}
    return render(request, 'general_templates/navbar/define/product/bulk_restore_ops.html', context)

# add product
@login_required(login_url='login')
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.instance.author = request.user
            product = form.save()
            #######################################
            if not NewTodoList.objects.filter(product=product).exists():
                # Create a related Backlog entry only if it doesn't exist
                backlog_title = f"{product.title} Backlog"
                backlog = NewTodoList.objects.create(title=backlog_title, 
                            product=product, active=True, author=request.user,
                            workitemtype=form.cleaned_data['work_item_type'])

            # Handle form submission success
            return redirect('navbar_product')
    else:
        form = ProductForm()
    
    context = {'page': 'Add Product', 'form': form}
    return render(request, 'general_templates/navbar/define/product/add_product.html', context)

@login_required(login_url='login')
def view_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    context = {'product': product}
    return render(request, 'general_templates/navbar/define/product/view_product.html', context)

@login_required(login_url='login')
def edit_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    form = ProductForm(instance=product)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            return redirect('navbar_product')
    else:
        form = ProductForm(instance=product)
    context = {'form': form, 'product': product}
    return render(request, 'general_templates/navbar/define/product/edit_product.html', context)

@login_required(login_url='login')
def delete_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    context = {'product': product}
    if request.method == 'POST':
        Product.objects.filter(id=pk).update(active=False,  author=request.user)
        return redirect('navbar_product')
    return render(request, 'general_templates/navbar/define/product/delete_product.html', context)

@login_required(login_url='login')
def restore_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    context = {'product': product}
    if request.method == 'POST':
        Product.objects.filter(id=pk).update(active=True,  author=request.user)
        return redirect('restore_products')
    return render(request, 'general_templates/navbar/define/product/restore_product.html', context)

@login_required(login_url='login')
def copy_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    new_product = Product()
    new_product.title = product.title + " (Copy)"
    new_product.description = product.description
    new_product.product_type = product.product_type
    new_product.product_priority = product.product_priority
    new_product.product_state = product.product_state
    new_product.start_date = product.start_date
    new_product.end_date = product.end_date
    new_product.current_state = product.current_state

    new_product.save()
    new_product_id = new_product.id
    context = {'product': product, 'new_product_id':new_product_id, 'new_product':new_product}
    return render(request, 'general_templates/navbar/define/product/copy_product.html', context)
