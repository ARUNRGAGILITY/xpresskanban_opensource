from django.shortcuts import render, redirect, get_object_or_404, HttpResponse
from ..models import *
from ..forms import *
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from mptt.exceptions import InvalidMove
from copy import copy
from copy import deepcopy
from mptt.exceptions import InvalidMove
from mptt.utils import tree_item_iterator
from mptt.templatetags.mptt_tags import cache_tree_children
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from app_todolist.models import * 

@login_required(login_url='login')
def navbar_vsm(request):
    context = {'page': 'VSM'}
    pagination_on = False
    # here we list all projects
    newtodolist = VSM.objects.filter(active=True).order_by('position')
    newtodolist_count = newtodolist.count()
    form = VSMS_Steps_Form(request.user)
    # pagination
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)
    
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 'pagination':selected_pagination, 'paginated_items': paginated_items, 'pagination_on': pagination_on}
    return render(request, 'general_templates/navbar/refine/navbar_vsm.html', context)

@login_required(login_url='login')
def list_vsm(request):
    context = {'page': 'VSM'}
    pagination_on = False
    # here we list all projects
    newtodolist = VSM.objects.filter(active=True).order_by('position')
    newtodolist_count = newtodolist.count()
    form = VSMForm(request.user)
    # pagination
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)
    
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 
               'pagination':selected_pagination, 'paginated_items': paginated_items, 
               'pagination_on': pagination_on}
    return render(request, 'general_templates/navbar/refine/vsm/list_vsm.html', context)

@login_required(login_url='login')
def add_vsm(request):
    if request.method == 'POST':
        form = VSMForm(request.POST)
        if form.is_valid():
            form.instance.author = request.user
            vsm = form.save()
            print(f">>>>>>>>>>>>>> NEW VSM creation  {vsm}")
            #######################################
            if not NewTodoList.objects.filter(vsm=vsm).exists():
                # Create a related Backlog entry only if it doesn't exist
                backlog_title = f"{vsm.title} Value Stream"
                backlog = NewTodoList.objects.create(title=backlog_title, 
                            vsm=vsm, active=True, author=request.user,
                            workitemtype=form.cleaned_data['work_item_type'])
            
            # Handle form submission success
            return redirect('navbar_vsm')
    else:
        form = VSMForm()
    
    context = {'page': 'Add VSM', 'form': form}
    return render(request, 'general_templates/navbar/refine/vsm/add_vsm.html', context)

@login_required(login_url='login')
def view_vsm(request, pk):
    vsm = get_object_or_404(VSM, pk=pk)
    context = {'product': vsm}
    return render(request, 'general_templates/navbar/refine/vsm/view_vsm.html', context)


@login_required(login_url='login')
def vsm_homepage(request, pk):
    form = VSMForm()
    vsm = get_object_or_404(VSM, pk=pk)
    backlogs = vsm.vsm_vs.all()
    backlog = get_object_or_404(NewTodoList, vsm=vsm)
    newtodolistitems = vsm
    newtodolistitems_count = vsm.vsm_vs.filter(active=True).count()
    if request.method == 'POST':
        print(f"Received VSM HOME PAGE >>>> FORM")
    context = {'newtodolistitems': newtodolistitems, 'form': form, 'backlog_id': backlog.id,
               'backlog': backlog,
               'todolist_parent_id ': pk, 'newtodolistitems_count': newtodolistitems_count, 
               'project': vsm, 'backlogs':backlogs}
    return render(request, 'general_templates/navbar/refine/vsm/vsm_homepage.html', context)


@login_required(login_url='login')
def edit_vsm(request, pk):
    vsm = get_object_or_404(VSM, pk=pk)
    form = VSMForm(instance=vsm)
    if request.method == 'POST':
        form = VSMForm(request.POST, instance=vsm)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            return redirect('navbar_vsm')
    else:
        form = VSMForm(instance=vsm)
    context = {'form': form, 'product': vsm}
    return render(request, 'general_templates/navbar/refine/vsm/edit_vsm.html', context)



@login_required(login_url='login')
def delete_vsm(request, pk):
    vsm = get_object_or_404(VSM, pk=pk)
    context = {'product': vsm}
    if request.method == 'POST':
        VSM.objects.filter(id=pk).update(active=False, deleted=False,  author=request.user)
        return redirect('navbar_vsm')
    return render(request, 'general_templates/navbar/refine/vsm/delete_vsm.html', context)

@login_required(login_url='login')
def restore_vsm(request, pk):
    vsm = get_object_or_404(VSM, pk=pk)
    context = {'project': vsm}
    if request.method == 'POST':
        VSM.objects.filter(id=pk).update(active=True,  author=request.user)
        return redirect('restore_vsms')
    return render(request, 'general_templates/navbar/refine/vsm/restore_vsm.html', context)

@login_required(login_url='login')
def copy_vsm(request, pk):
    product = get_object_or_404(VSM, pk=pk)
    new_product = VSM()
    new_product.title = product.title + " (Copy)"
    new_product.description = product.description
    new_product.work_item_type = product.work_item_type
    new_product.save()
    new_product_id = new_product.id
    context = {'product': product, 'new_product_id':new_product_id, 'new_product':new_product}
    return render(request, 'general_templates/navbar/refine/vsm/copy_vsm.html', context)

@login_required(login_url='login')
def ops_vsm(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_project_ids = request.POST.getlist('product_box')        
        bulk_ops = form_data.get('bulk_vsm_ops')
        pagination = form_data.get('pagination')
        bulk_ops = form_data.get('bulk_vsm_ops')
        if bulk_ops == "bulk_delete":
            for id in selected_project_ids:
                VSM.objects.filter(id=id).update(active=False, deleted=False,  author=request.user)
        elif bulk_ops == "bulk_done":
            for id in selected_project_ids:
                VSM.objects.filter(id=id).update(done=True,  author=request.user)
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 
                   'selected_product_ids':selected_project_ids}
    return render(request, 'general_templates/navbar/refine/vsm/bulk_vsm_ops.html', context)

@login_required(login_url='login')
def bulk_restore_deleted_vsms(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_project_ids = request.POST.getlist('restore_product_box')        
        bulk_ops = form_data.get('bulk_vsm_ops')
        if bulk_ops == "bulk_restore":
            for id in selected_project_ids:
                VSM.objects.filter(id=id).update(active=True,  author=request.user)
        elif bulk_ops == "bulk_not_done":
            for id in selected_project_ids:
                VSM.objects.filter(id=id).update(done=False,  author=request.user)
        elif bulk_ops == "bulk_delete_permanently":
            for id in selected_project_ids:
                VSM.objects.filter(id=id).update(active=False, deleted=True,  author=request.user)
        pagination = form_data.get('pagination')
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 
                   'selected_product_ids':selected_project_ids}
    return render(request, 'general_templates/navbar/refine/vsm/bulk_restore_ops.html', context)

@login_required(login_url='login')
def vsm_sorted(request):
    if request.method == 'POST':
        ajax_data = request.POST['sorted_list_data']
        new_data = ajax_data.replace("[",'')
        new_data = new_data.replace("]",'')
        sorted_list = new_data.split(",")
        seq = 1
        for item in sorted_list:
            str = item.replace('"','')
            position = str.split('_')
            VSM.objects.filter(pk=position[0]).update(position=seq)
            seq = seq + 1
        return render(request, 'general_templates/navbar/refine/navbar_vsm.html', {'ajax_data': ajax_data})
    
@login_required(login_url='login')
def restore_vsms(request):
    context = {'page': 'Restore VSMs'}
    # here we list all projects deleted and restore
    newtodolist = VSM.objects.filter(active=False, deleted=False).order_by('position')
    newtodolist_count = newtodolist.count()
    form = VSMForm(request.user)
    if request.method == 'POST':
        form = VSMForm(request.user, request.POST)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            todo_count = newtodolist.count()
            return redirect('navbar_project')
        else:
            print(f"form is invalid {form}")
    context = {'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count}
    return render(request, 'general_templates/navbar/refine/vsm/restore_vsms.html', context)

## vsms 
@login_required(login_url='login')
def main_vsms_steps(request, vsm_id):
    vsm = None
    main_vsm = get_object_or_404(NewTodoList, id=vsm_id)
    vsm_parent = main_vsm.parent_id

    # get VSMS_info
    vsms_info_obj = VSMS_Info.objects.filter(active=True, vsms=vsm_id).first()

    form = VSMS_Steps_Form(request.user)   
    vsms_info = None
    newtodolist = VSMS_Steps.objects.filter(active=True, vsms=vsm_id).order_by('position')
    newtodolist_count = newtodolist.count()

    # pagination
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)
    if request.method == 'POST':
        form = VSMS_Steps_Form(request.POST)
        info_id = VSMS_Info.objects.get(vsms=main_vsm)
        if form.is_valid():
            form.instance.info = info_id
            form.instance.vsms_id = vsm_id
            form.instance.author = request.user
            vsm = form.save()

            ## saving VSMS INFO
            calculate_vsm_info_details(request, vsm_id)
            ref_vsms = vsm.vsms.id
            # Handle form submission success
            return redirect('main_vsms_steps', vsm_id=vsm_id)
    else:
        form = VSMS_Steps_Form()
    print(f">>>> PAGINATED_ITEMS {paginated_items}")
    context = {'vsm_parent':vsm_parent, 'main_vsm': main_vsm, 'vsm': vsm, 'vsm_id': vsm_id, 'page': 'Add VSMS Steps',
               'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 
               'pagination':selected_pagination, 'paginated_items': paginated_items, 
               'pagination_on': pagination_on,
               'vsms_info_obj':vsms_info_obj,}
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/main_vsms_steps.html', context)

## vsms 
@login_required(login_url='login')
def visual_main_vsms_steps(request, vsm_id):
    vsm = None
    row = None
    main_vsm = get_object_or_404(NewTodoList, id=vsm_id)
    vsm_parent = main_vsm.parent_id

    # get VSMS_info
    vsms_info_obj = VSMS_Info.objects.filter(active=True, vsms=vsm_id).first()

    form = VSMS_Steps_Form(request.user)   
    vsms_info = None
    newtodolist = VSMS_Steps.objects.filter(active=True, vsms=vsm_id).order_by('position')
    newtodolist_count = newtodolist.count()
    columns_per_row = 4
    rows = [newtodolist[i:i + columns_per_row] for i in range(0, len(newtodolist), columns_per_row)]
    
    if request.method == 'POST':
        form = VSMS_Steps_Form(request.POST)
        info_id = VSMS_Info.objects.get(vsms=main_vsm)
        if form.is_valid():
            form.instance.info = info_id
            form.instance.vsms_id = vsm_id
            form.instance.author = request.user
            vsm = form.save()

            ## saving VSMS INFO
            calculate_vsm_info_details(request, vsm_id)
            ref_vsms = vsm.vsms.id
            # Handle form submission success
            return redirect('main_vsms_steps', vsm_id=vsm_id)
    else:
        form = VSMS_Steps_Form()
    
    context = {'vsm_parent':vsm_parent, 'main_vsm': main_vsm, 'vsm': vsm, 'vsm_id': vsm_id, 'page': 'Add VSMS Steps',
               'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 
               'rows': rows, 'columns_per_row': columns_per_row,
               'vsms_info_obj':vsms_info_obj,}
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/visual_main_vsms_steps.html', context)



@login_required(login_url='login')
def ops_vsms_steps(request):
    if request.method == 'POST':
        form_data = request.POST
        selected_project_ids = request.POST.getlist('product_box')        
        bulk_ops = form_data.get('bulk_vsm_ops')
        pagination = form_data.get('pagination')
        bulk_ops = form_data.get('bulk_vsm_ops')
        if bulk_ops == "bulk_delete":
            for id in selected_project_ids:
                VSMS_Steps.objects.filter(id=id).update(active=False, deleted=False,  author=request.user)
        elif bulk_ops == "bulk_done":
            for id in selected_project_ids:
                VSMS_Steps.objects.filter(id=id).update(done=True,  author=request.user)
        context = {'bulk_ops': bulk_ops, 'pagination': pagination, 
                   'selected_product_ids':selected_project_ids}
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/bulk_vsms_steps_ops.html', context)

@login_required(login_url='login')
def vsms_steps_sorted(request):
    if request.method == 'POST':
        ajax_data = request.POST['sorted_list_data']
        new_data = ajax_data.replace("[",'')
        new_data = new_data.replace("]",'')
        sorted_list = new_data.split(",")
        seq = 1
        for item in sorted_list:
            str = item.replace('"','')
            position = str.split('_')
            VSMS_Steps.objects.filter(pk=position[0]).update(position=seq)
            seq = seq + 1
        return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/main_vsms_steps.html', {'ajax_data': ajax_data})

@login_required(login_url='login')
def add_vsms_steps(request, vsm_id):
    vsm = None
    main_vsm = get_object_or_404(NewTodoList, id=vsm_id)
    vsm_parent = main_vsm.parent_id
    form = VSMS_Steps_Form(request.user)   
    vsms_info = None
    newtodolist = VSMS_Steps.objects.filter(active=True, vsms=vsm_id).order_by('position')
    newtodolist_count = newtodolist.count()

    # pagination
    selected_pagination = request.GET.get('pagination', 'all')
    #selected_pagination = 'all'
    if selected_pagination == 'all':
        paginated_items = newtodolist
        pagination_on = False
    else:
        pagination_on = True
        items_per_page = int(selected_pagination) 
        paginator = Paginator(newtodolist, items_per_page)        

        page_number = request.GET.get('page')
        try:
            paginated_items = paginator.page(page_number)
        except PageNotAnInteger:
            paginated_items = paginator.page(1)
        except EmptyPage:
            paginated_items = paginator.page(paginator.num_pages)
    # get VSMS_info
    vsms_info_obj = VSMS_Info.objects.filter(active=True, vsms=vsm_id).first()
    if request.method == 'POST':
        form = VSMS_Steps_Form(request.POST)
        if form.is_valid():
           info_id = VSMS_Info.objects.get(vsms=main_vsm)
        if form.is_valid():
            form.instance.info = info_id
            form.instance.vsms_id = vsm_id
            form.instance.author = request.user
            vsm = form.save()
            calculate_vsm_info_details(request, vsm_id)
          
            ref_vsms = vsm.vsms.id
            # Handle form submission success
            return redirect('main_vsms_steps', vsm_id=vsm_id)
    else:
        form = VSMS_Steps_Form()
    
    context = {'vsm_parent':vsm_parent, 'main_vsm': main_vsm, 'vsm': vsm, 'vsm_id': vsm_id, 
               'page': 'Add VSMS Steps',
               'newtodolist': newtodolist,'form':form, 'newtodolist_count': newtodolist_count, 
               'pagination':selected_pagination, 'paginated_items': paginated_items, 
               'pagination_on': pagination_on,
               'vsms_info_obj':vsms_info_obj,}
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/add_vsms_step.html', context)

def calculate_vsm_info_details(request, vsm_id):
    all_steps = VSMS_Steps.objects.filter(vsms=vsm_id, active=True)
    main_vsm = get_object_or_404(NewTodoList, id=vsm_id)
    tvt = 0
    tnvt = 0
    rca = 1
    first_iteration = True
    for step in all_steps:
        tvt = step.value_time + tvt
        tnvt = step.non_value_time + tnvt
        if rca > 0 :
            rca = step.percentage_accurate * rca
        if first_iteration == True:
            first_iteration = False
            continue
        print(f">>>>>> rca = step.percentage_accurate * spa => {step.percentage_accurate} * {rca} = {rca}")
    print(f">>>>>>>>>>>> RCA BF % {rca}")    
    rca = rca * 100
    print(f">>>>>>>>>>>> RCA AF % {rca}")
    print(f"CALCULATION: tvt {tvt} tnvt {tnvt}")
    etet = tvt + tnvt
    if tvt > 0 and etet > 0:
        oe = (tvt/etet)*100
    else:
        oe = 0
    info_title = "vsm info"
    vsms_info_obj = VSMS_Info.objects.filter(vsms=main_vsm).update(
                title=info_title, 
                vsms=main_vsm, active=True, author=request.user,
                total_value_time=tvt, total_non_value_time=tnvt,
                end_to_end_time=etet, organization_efficiency=oe,
                rolled_ca = rca)

## start automating 
@login_required(login_url='login')
def view_vsms_steps(request, pk):
    object = get_object_or_404(VSMS_Steps, pk=pk)
    context = {'object': object}
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/view_vsms_steps.html', context)

@login_required(login_url='login')
def edit_vsms_steps(request, pk):
    object = get_object_or_404(VSMS_Steps, pk=pk)
    pid = object.vsms.id
    form = VSMS_Steps_Form(instance=object)
    if request.method == 'POST':
        form = VSMS_Steps_Form(request.POST, instance=object)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            calculate_vsm_info_details(request, pid)
            return redirect('main_vsms_steps', vsm_id=pid)
    else:
        form = VSMS_Steps_Form(instance=object)
    context = {'form': form, 'object': object, 'vsm_id': pid}
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/edit_vsms_steps.html', context)

@login_required(login_url='login')
def delete_vsms_steps(request, pk):
    object = get_object_or_404(VSMS_Steps, pk=pk)
    pid = object.vsms.id
    print(f">>>>>>>>>>>>>>> DELETE VSMS {pid}")
    context = {'object': object, 'vsm_id': pid}
    if request.method == 'POST':
        VSMS_Steps.objects.filter(id=pk).update(active=False, deleted=False,  author=request.user)
        calculate_vsm_info_details(request, pid)
        return redirect('main_vsms_steps', vsm_id=pid)
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/delete_vsms_steps.html', context)

@login_required(login_url='login')
def copy_vsms_steps(request, pk):
    object = get_object_or_404(VSMS_Steps, pk=pk)
    pid = object.vsms.id
    new_object = VSMS_Steps()
    new_object.vsms = object.vsms
    new_object.title = object.title + " (Copy)"
    new_object.description = object.description
    new_object.value_time = object.value_time
    new_object.non_value_time = object.non_value_time
    new_object.percentage_accurate = object.percentage_accurate
    new_object.save()
    new_object_id = new_object.id
    calculate_vsm_info_details(request, pid)
    context = {'object': object, 'new_object_id':new_object_id, 'new_object':new_object,
               'vsm_id':pid}
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/copy_vsms_steps.html', context)

@login_required(login_url='login')
def restore_vsms_steps(request):
    context = {'page': 'Restore VSM Steps'}
    # here we list all projects deleted and restore
    newtodolist = VSMS_Steps.objects.filter(active=False, deleted=False).order_by('position')
    newtodolist_count = newtodolist.count()
    form = VSMS_Steps_Form(request.user)
    if request.method == 'POST':
        form = VSMS_Steps_Form(request.user, request.POST)
        if form.is_valid():
            form.instance.author = request.user
            form.save()
            todo_count = newtodolist.count()
            return redirect('main_vsms_steps', vsm_id=pid)
        else:
            print(f"form is invalid {form}")
    context = {'newtodolist': newtodolist,'form':form, 
               'newtodolist_count': newtodolist_count
               }
    return render(request, 'general_templates/navbar/refine/vsm/vsms_steps/restore_vsms_steps.html', context)
